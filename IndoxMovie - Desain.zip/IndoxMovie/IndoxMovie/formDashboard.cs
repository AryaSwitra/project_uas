﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace IndoxMovie
{
    public partial class formDashboard : Form
    {
        public formDashboard()
        {
            InitializeComponent();
        }

        private void imgJumanji_Click(object sender, EventArgs e)
        {
        }

        private void imgJoker_Click(object sender, EventArgs e)
        {

        }

        private void imgJumanji_Click_1(object sender, EventArgs e)
        {
            panelListFilm.Visible = false;
            panelOrder.Visible = true;
            imgMovie.BackgroundImage = IndoxMovie.Properties.Resources.JUMANJI___THE_NEXT_LEVEL;
        }

        private void imgJeritanMalam_Click(object sender, EventArgs e)
        {
            panelListFilm.Visible = false;
            panelOrder.Visible = true;
            imgMovie.BackgroundImage = IndoxMovie.Properties.Resources.JERITAN_MALAM;
        }

        private void imgFrozen2_Click(object sender, EventArgs e)
        {
            panelListFilm.Visible = false;
            panelOrder.Visible = true;
            imgMovie.BackgroundImage = IndoxMovie.Properties.Resources.FROZEN_2;
        }

        private void imgBlackChristmas_Click(object sender, EventArgs e)
        {
            panelListFilm.Visible = false;
            panelOrder.Visible = true;
            imgMovie.BackgroundImage = IndoxMovie.Properties.Resources.BLACK_CHRISTMAS;
        }

        private void imgJoker_Click_1(object sender, EventArgs e)
        {
            panelListFilm.Visible = false;
            panelOrder.Visible = true;
            imgMovie.BackgroundImage = IndoxMovie.Properties.Resources.JOKER;
        }

        private void imgRasuk2_Click(object sender, EventArgs e)
        {
            panelListFilm.Visible = false;
            panelOrder.Visible = true;
            imgMovie.BackgroundImage = IndoxMovie.Properties.Resources.RASUK_2;
        }

        private void imgUnderwater_Click(object sender, EventArgs e)
        {
            panelListFilm.Visible = false;
            panelOrder.Visible = true;
            imgMovie.BackgroundImage = IndoxMovie.Properties.Resources.UNDERWATER;
        }

        private void imgDabangg3_Click(object sender, EventArgs e)
        {
            panelListFilm.Visible = false;
            panelOrder.Visible = true;
            imgMovie.BackgroundImage = IndoxMovie.Properties.Resources.DABANGG_3;
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            panelDetailOrder.Visible = false;
            panelOrder.Visible = true;
        }

        private void button52_Click(object sender, EventArgs e)
        {
            panelOrder.Visible = false;
            panelListFilm.Visible = true;
        }

        private void button51_Click(object sender, EventArgs e)
        {
            panelOrder.Visible = false;
            panelDetailOrder.Visible = true;
        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            formInvoice formInvoice = new formInvoice();
            formInvoice.Show();
            this.Hide();
        }

    }
}
