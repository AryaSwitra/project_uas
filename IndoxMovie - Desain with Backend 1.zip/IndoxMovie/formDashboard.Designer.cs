﻿namespace IndoxMovie
{
    partial class formDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelListFilm = new System.Windows.Forms.Panel();
            this.imgDabangg3 = new System.Windows.Forms.Button();
            this.imgUnderwater = new System.Windows.Forms.Button();
            this.imgRasuk2 = new System.Windows.Forms.Button();
            this.imgJoker = new System.Windows.Forms.Button();
            this.imgBlackChristmas = new System.Windows.Forms.Button();
            this.imgFrozen2 = new System.Windows.Forms.Button();
            this.imgJeritanMalam = new System.Windows.Forms.Button();
            this.imgJumanji = new System.Windows.Forms.Button();
            this.panelOrder = new System.Windows.Forms.Panel();
            this.button51 = new System.Windows.Forms.Button();
            this.button52 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.button41 = new System.Windows.Forms.Button();
            this.button42 = new System.Windows.Forms.Button();
            this.button43 = new System.Windows.Forms.Button();
            this.button44 = new System.Windows.Forms.Button();
            this.button45 = new System.Windows.Forms.Button();
            this.button46 = new System.Windows.Forms.Button();
            this.button47 = new System.Windows.Forms.Button();
            this.button48 = new System.Windows.Forms.Button();
            this.button49 = new System.Windows.Forms.Button();
            this.button50 = new System.Windows.Forms.Button();
            this.button31 = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.button33 = new System.Windows.Forms.Button();
            this.button34 = new System.Windows.Forms.Button();
            this.button35 = new System.Windows.Forms.Button();
            this.button36 = new System.Windows.Forms.Button();
            this.button37 = new System.Windows.Forms.Button();
            this.button38 = new System.Windows.Forms.Button();
            this.button39 = new System.Windows.Forms.Button();
            this.button40 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.button30 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.cbTime = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.imgMovie = new System.Windows.Forms.Button();
            this.panelDetailOrder = new System.Windows.Forms.Panel();
            this.btnConfirm = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.txtTime = new System.Windows.Forms.Label();
            this.txtDateTicket = new System.Windows.Forms.Label();
            this.txtSeat = new System.Windows.Forms.Label();
            this.txtPrice = new System.Windows.Forms.Label();
            this.txtTitle = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.imgDetailOrder = new System.Windows.Forms.Button();
            this.panelListFilm.SuspendLayout();
            this.panelOrder.SuspendLayout();
            this.panelDetailOrder.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelListFilm
            // 
            this.panelListFilm.BackgroundImage = global::IndoxMovie.Properties.Resources.bg_listFilm;
            this.panelListFilm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panelListFilm.Controls.Add(this.imgDabangg3);
            this.panelListFilm.Controls.Add(this.imgUnderwater);
            this.panelListFilm.Controls.Add(this.imgRasuk2);
            this.panelListFilm.Controls.Add(this.imgJoker);
            this.panelListFilm.Controls.Add(this.imgBlackChristmas);
            this.panelListFilm.Controls.Add(this.imgFrozen2);
            this.panelListFilm.Controls.Add(this.imgJeritanMalam);
            this.panelListFilm.Controls.Add(this.imgJumanji);
            this.panelListFilm.Location = new System.Drawing.Point(0, 0);
            this.panelListFilm.Margin = new System.Windows.Forms.Padding(0);
            this.panelListFilm.Name = "panelListFilm";
            this.panelListFilm.Size = new System.Drawing.Size(885, 565);
            this.panelListFilm.TabIndex = 11;
            // 
            // imgDabangg3
            // 
            this.imgDabangg3.BackColor = System.Drawing.Color.Transparent;
            this.imgDabangg3.BackgroundImage = global::IndoxMovie.Properties.Resources.DABANGG_3;
            this.imgDabangg3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.imgDabangg3.FlatAppearance.BorderSize = 0;
            this.imgDabangg3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.imgDabangg3.ForeColor = System.Drawing.Color.Transparent;
            this.imgDabangg3.Location = new System.Drawing.Point(679, 341);
            this.imgDabangg3.Name = "imgDabangg3";
            this.imgDabangg3.Size = new System.Drawing.Size(128, 151);
            this.imgDabangg3.TabIndex = 25;
            this.imgDabangg3.UseVisualStyleBackColor = false;
            this.imgDabangg3.Click += new System.EventHandler(this.imgDabangg3_Click);
            // 
            // imgUnderwater
            // 
            this.imgUnderwater.BackColor = System.Drawing.Color.Transparent;
            this.imgUnderwater.BackgroundImage = global::IndoxMovie.Properties.Resources.UNDERWATER;
            this.imgUnderwater.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.imgUnderwater.FlatAppearance.BorderSize = 0;
            this.imgUnderwater.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.imgUnderwater.ForeColor = System.Drawing.Color.Transparent;
            this.imgUnderwater.Location = new System.Drawing.Point(478, 341);
            this.imgUnderwater.Name = "imgUnderwater";
            this.imgUnderwater.Size = new System.Drawing.Size(128, 151);
            this.imgUnderwater.TabIndex = 24;
            this.imgUnderwater.UseVisualStyleBackColor = false;
            this.imgUnderwater.Click += new System.EventHandler(this.imgUnderwater_Click);
            // 
            // imgRasuk2
            // 
            this.imgRasuk2.BackColor = System.Drawing.Color.Transparent;
            this.imgRasuk2.BackgroundImage = global::IndoxMovie.Properties.Resources.RASUK_2;
            this.imgRasuk2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.imgRasuk2.FlatAppearance.BorderSize = 0;
            this.imgRasuk2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.imgRasuk2.ForeColor = System.Drawing.Color.Transparent;
            this.imgRasuk2.Location = new System.Drawing.Point(276, 341);
            this.imgRasuk2.Name = "imgRasuk2";
            this.imgRasuk2.Size = new System.Drawing.Size(128, 151);
            this.imgRasuk2.TabIndex = 23;
            this.imgRasuk2.UseVisualStyleBackColor = false;
            this.imgRasuk2.Click += new System.EventHandler(this.imgRasuk2_Click);
            // 
            // imgJoker
            // 
            this.imgJoker.BackColor = System.Drawing.Color.Transparent;
            this.imgJoker.BackgroundImage = global::IndoxMovie.Properties.Resources.JOKER;
            this.imgJoker.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.imgJoker.FlatAppearance.BorderSize = 0;
            this.imgJoker.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.imgJoker.ForeColor = System.Drawing.Color.Transparent;
            this.imgJoker.Location = new System.Drawing.Point(75, 341);
            this.imgJoker.Name = "imgJoker";
            this.imgJoker.Size = new System.Drawing.Size(128, 151);
            this.imgJoker.TabIndex = 22;
            this.imgJoker.UseVisualStyleBackColor = false;
            this.imgJoker.Click += new System.EventHandler(this.imgJoker_Click_1);
            // 
            // imgBlackChristmas
            // 
            this.imgBlackChristmas.BackColor = System.Drawing.Color.Transparent;
            this.imgBlackChristmas.BackgroundImage = global::IndoxMovie.Properties.Resources.BLACK_CHRISTMAS;
            this.imgBlackChristmas.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.imgBlackChristmas.FlatAppearance.BorderSize = 0;
            this.imgBlackChristmas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.imgBlackChristmas.ForeColor = System.Drawing.Color.Transparent;
            this.imgBlackChristmas.Location = new System.Drawing.Point(679, 122);
            this.imgBlackChristmas.Name = "imgBlackChristmas";
            this.imgBlackChristmas.Size = new System.Drawing.Size(128, 151);
            this.imgBlackChristmas.TabIndex = 21;
            this.imgBlackChristmas.UseVisualStyleBackColor = false;
            this.imgBlackChristmas.Click += new System.EventHandler(this.imgBlackChristmas_Click);
            // 
            // imgFrozen2
            // 
            this.imgFrozen2.BackColor = System.Drawing.Color.Transparent;
            this.imgFrozen2.BackgroundImage = global::IndoxMovie.Properties.Resources.FROZEN_2;
            this.imgFrozen2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.imgFrozen2.FlatAppearance.BorderSize = 0;
            this.imgFrozen2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.imgFrozen2.ForeColor = System.Drawing.Color.Transparent;
            this.imgFrozen2.Location = new System.Drawing.Point(478, 122);
            this.imgFrozen2.Name = "imgFrozen2";
            this.imgFrozen2.Size = new System.Drawing.Size(128, 151);
            this.imgFrozen2.TabIndex = 20;
            this.imgFrozen2.UseVisualStyleBackColor = false;
            this.imgFrozen2.Click += new System.EventHandler(this.imgFrozen2_Click);
            // 
            // imgJeritanMalam
            // 
            this.imgJeritanMalam.BackColor = System.Drawing.Color.Transparent;
            this.imgJeritanMalam.BackgroundImage = global::IndoxMovie.Properties.Resources.JERITAN_MALAM;
            this.imgJeritanMalam.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.imgJeritanMalam.FlatAppearance.BorderSize = 0;
            this.imgJeritanMalam.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.imgJeritanMalam.ForeColor = System.Drawing.Color.Transparent;
            this.imgJeritanMalam.Location = new System.Drawing.Point(276, 122);
            this.imgJeritanMalam.Name = "imgJeritanMalam";
            this.imgJeritanMalam.Size = new System.Drawing.Size(128, 151);
            this.imgJeritanMalam.TabIndex = 19;
            this.imgJeritanMalam.UseVisualStyleBackColor = false;
            this.imgJeritanMalam.Click += new System.EventHandler(this.imgJeritanMalam_Click);
            // 
            // imgJumanji
            // 
            this.imgJumanji.BackColor = System.Drawing.Color.Transparent;
            this.imgJumanji.BackgroundImage = global::IndoxMovie.Properties.Resources.JUMANJI___THE_NEXT_LEVEL;
            this.imgJumanji.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.imgJumanji.FlatAppearance.BorderSize = 0;
            this.imgJumanji.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.imgJumanji.ForeColor = System.Drawing.Color.Transparent;
            this.imgJumanji.Location = new System.Drawing.Point(75, 122);
            this.imgJumanji.Name = "imgJumanji";
            this.imgJumanji.Size = new System.Drawing.Size(128, 151);
            this.imgJumanji.TabIndex = 18;
            this.imgJumanji.UseVisualStyleBackColor = false;
            this.imgJumanji.Click += new System.EventHandler(this.imgJumanji_Click_1);
            // 
            // panelOrder
            // 
            this.panelOrder.BackgroundImage = global::IndoxMovie.Properties.Resources.bg_order;
            this.panelOrder.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panelOrder.Controls.Add(this.button51);
            this.panelOrder.Controls.Add(this.button52);
            this.panelOrder.Controls.Add(this.label5);
            this.panelOrder.Controls.Add(this.button41);
            this.panelOrder.Controls.Add(this.button42);
            this.panelOrder.Controls.Add(this.button43);
            this.panelOrder.Controls.Add(this.button44);
            this.panelOrder.Controls.Add(this.button45);
            this.panelOrder.Controls.Add(this.button46);
            this.panelOrder.Controls.Add(this.button47);
            this.panelOrder.Controls.Add(this.button48);
            this.panelOrder.Controls.Add(this.button49);
            this.panelOrder.Controls.Add(this.button50);
            this.panelOrder.Controls.Add(this.button31);
            this.panelOrder.Controls.Add(this.button32);
            this.panelOrder.Controls.Add(this.button33);
            this.panelOrder.Controls.Add(this.button34);
            this.panelOrder.Controls.Add(this.button35);
            this.panelOrder.Controls.Add(this.button36);
            this.panelOrder.Controls.Add(this.button37);
            this.panelOrder.Controls.Add(this.button38);
            this.panelOrder.Controls.Add(this.button39);
            this.panelOrder.Controls.Add(this.button40);
            this.panelOrder.Controls.Add(this.button21);
            this.panelOrder.Controls.Add(this.button22);
            this.panelOrder.Controls.Add(this.button23);
            this.panelOrder.Controls.Add(this.button24);
            this.panelOrder.Controls.Add(this.button25);
            this.panelOrder.Controls.Add(this.button26);
            this.panelOrder.Controls.Add(this.button27);
            this.panelOrder.Controls.Add(this.button28);
            this.panelOrder.Controls.Add(this.button29);
            this.panelOrder.Controls.Add(this.button30);
            this.panelOrder.Controls.Add(this.button6);
            this.panelOrder.Controls.Add(this.button7);
            this.panelOrder.Controls.Add(this.button13);
            this.panelOrder.Controls.Add(this.button14);
            this.panelOrder.Controls.Add(this.button15);
            this.panelOrder.Controls.Add(this.button16);
            this.panelOrder.Controls.Add(this.button17);
            this.panelOrder.Controls.Add(this.button18);
            this.panelOrder.Controls.Add(this.button19);
            this.panelOrder.Controls.Add(this.button20);
            this.panelOrder.Controls.Add(this.button9);
            this.panelOrder.Controls.Add(this.button10);
            this.panelOrder.Controls.Add(this.button11);
            this.panelOrder.Controls.Add(this.button12);
            this.panelOrder.Controls.Add(this.button5);
            this.panelOrder.Controls.Add(this.button8);
            this.panelOrder.Controls.Add(this.button3);
            this.panelOrder.Controls.Add(this.button4);
            this.panelOrder.Controls.Add(this.button2);
            this.panelOrder.Controls.Add(this.label4);
            this.panelOrder.Controls.Add(this.button1);
            this.panelOrder.Controls.Add(this.label3);
            this.panelOrder.Controls.Add(this.cbTime);
            this.panelOrder.Controls.Add(this.label2);
            this.panelOrder.Controls.Add(this.label1);
            this.panelOrder.Controls.Add(this.dateTimePicker1);
            this.panelOrder.Controls.Add(this.imgMovie);
            this.panelOrder.Location = new System.Drawing.Point(0, -1);
            this.panelOrder.Margin = new System.Windows.Forms.Padding(0);
            this.panelOrder.Name = "panelOrder";
            this.panelOrder.Size = new System.Drawing.Size(885, 565);
            this.panelOrder.TabIndex = 12;
            this.panelOrder.Visible = false;
            // 
            // button51
            // 
            this.button51.BackColor = System.Drawing.Color.Transparent;
            this.button51.BackgroundImage = global::IndoxMovie.Properties.Resources.btn_confirm;
            this.button51.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button51.FlatAppearance.BorderSize = 0;
            this.button51.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button51.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button51.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button51.ForeColor = System.Drawing.Color.Transparent;
            this.button51.Location = new System.Drawing.Point(708, 45);
            this.button51.Name = "button51";
            this.button51.Size = new System.Drawing.Size(150, 47);
            this.button51.TabIndex = 80;
            this.button51.UseVisualStyleBackColor = false;
            this.button51.Click += new System.EventHandler(this.button51_Click);
            // 
            // button52
            // 
            this.button52.BackColor = System.Drawing.Color.Transparent;
            this.button52.BackgroundImage = global::IndoxMovie.Properties.Resources.btn_cancel;
            this.button52.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button52.FlatAppearance.BorderSize = 0;
            this.button52.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button52.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button52.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button52.ForeColor = System.Drawing.Color.Transparent;
            this.button52.Location = new System.Drawing.Point(527, 45);
            this.button52.Name = "button52";
            this.button52.Size = new System.Drawing.Size(150, 47);
            this.button52.TabIndex = 79;
            this.button52.UseVisualStyleBackColor = false;
            this.button52.Click += new System.EventHandler(this.button52_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Franklin Gothic Medium", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(542, 509);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(93, 15);
            this.label5.TabIndex = 78;
            this.label5.Text = "----- screen -----";
            // 
            // button41
            // 
            this.button41.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button41.Location = new System.Drawing.Point(819, 207);
            this.button41.Name = "button41";
            this.button41.Size = new System.Drawing.Size(39, 36);
            this.button41.TabIndex = 77;
            this.button41.Text = "A10";
            this.button41.UseVisualStyleBackColor = true;
            // 
            // button42
            // 
            this.button42.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button42.Location = new System.Drawing.Point(766, 207);
            this.button42.Name = "button42";
            this.button42.Size = new System.Drawing.Size(39, 36);
            this.button42.TabIndex = 76;
            this.button42.Text = "A9";
            this.button42.UseVisualStyleBackColor = true;
            // 
            // button43
            // 
            this.button43.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button43.Location = new System.Drawing.Point(713, 207);
            this.button43.Name = "button43";
            this.button43.Size = new System.Drawing.Size(39, 36);
            this.button43.TabIndex = 75;
            this.button43.Text = "A8";
            this.button43.UseVisualStyleBackColor = true;
            // 
            // button44
            // 
            this.button44.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button44.Location = new System.Drawing.Point(661, 207);
            this.button44.Name = "button44";
            this.button44.Size = new System.Drawing.Size(39, 36);
            this.button44.TabIndex = 74;
            this.button44.Text = "A7";
            this.button44.UseVisualStyleBackColor = true;
            // 
            // button45
            // 
            this.button45.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button45.Location = new System.Drawing.Point(609, 207);
            this.button45.Name = "button45";
            this.button45.Size = new System.Drawing.Size(39, 36);
            this.button45.TabIndex = 73;
            this.button45.Text = "A6";
            this.button45.UseVisualStyleBackColor = true;
            // 
            // button46
            // 
            this.button46.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button46.Location = new System.Drawing.Point(532, 207);
            this.button46.Name = "button46";
            this.button46.Size = new System.Drawing.Size(39, 36);
            this.button46.TabIndex = 72;
            this.button46.Text = "A5";
            this.button46.UseVisualStyleBackColor = true;
            // 
            // button47
            // 
            this.button47.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button47.Location = new System.Drawing.Point(480, 207);
            this.button47.Name = "button47";
            this.button47.Size = new System.Drawing.Size(39, 36);
            this.button47.TabIndex = 71;
            this.button47.Text = "A4";
            this.button47.UseVisualStyleBackColor = true;
            // 
            // button48
            // 
            this.button48.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button48.Location = new System.Drawing.Point(427, 207);
            this.button48.Name = "button48";
            this.button48.Size = new System.Drawing.Size(39, 36);
            this.button48.TabIndex = 70;
            this.button48.Text = "A3";
            this.button48.UseVisualStyleBackColor = true;
            // 
            // button49
            // 
            this.button49.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button49.Location = new System.Drawing.Point(375, 207);
            this.button49.Name = "button49";
            this.button49.Size = new System.Drawing.Size(39, 36);
            this.button49.TabIndex = 69;
            this.button49.Text = "A2";
            this.button49.UseVisualStyleBackColor = true;
            // 
            // button50
            // 
            this.button50.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button50.Location = new System.Drawing.Point(323, 207);
            this.button50.Name = "button50";
            this.button50.Size = new System.Drawing.Size(39, 36);
            this.button50.TabIndex = 68;
            this.button50.Text = "A1";
            this.button50.UseVisualStyleBackColor = true;
            // 
            // button31
            // 
            this.button31.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button31.Location = new System.Drawing.Point(819, 270);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(39, 36);
            this.button31.TabIndex = 67;
            this.button31.Text = "A10";
            this.button31.UseVisualStyleBackColor = true;
            // 
            // button32
            // 
            this.button32.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button32.Location = new System.Drawing.Point(766, 270);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(39, 36);
            this.button32.TabIndex = 66;
            this.button32.Text = "A9";
            this.button32.UseVisualStyleBackColor = true;
            // 
            // button33
            // 
            this.button33.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button33.Location = new System.Drawing.Point(713, 270);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(39, 36);
            this.button33.TabIndex = 65;
            this.button33.Text = "A8";
            this.button33.UseVisualStyleBackColor = true;
            // 
            // button34
            // 
            this.button34.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button34.Location = new System.Drawing.Point(661, 270);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(39, 36);
            this.button34.TabIndex = 64;
            this.button34.Text = "A7";
            this.button34.UseVisualStyleBackColor = true;
            // 
            // button35
            // 
            this.button35.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button35.Location = new System.Drawing.Point(609, 270);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(39, 36);
            this.button35.TabIndex = 63;
            this.button35.Text = "A6";
            this.button35.UseVisualStyleBackColor = true;
            // 
            // button36
            // 
            this.button36.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button36.Location = new System.Drawing.Point(532, 270);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(39, 36);
            this.button36.TabIndex = 62;
            this.button36.Text = "A5";
            this.button36.UseVisualStyleBackColor = true;
            // 
            // button37
            // 
            this.button37.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button37.Location = new System.Drawing.Point(480, 270);
            this.button37.Name = "button37";
            this.button37.Size = new System.Drawing.Size(39, 36);
            this.button37.TabIndex = 61;
            this.button37.Text = "A4";
            this.button37.UseVisualStyleBackColor = true;
            // 
            // button38
            // 
            this.button38.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button38.Location = new System.Drawing.Point(427, 270);
            this.button38.Name = "button38";
            this.button38.Size = new System.Drawing.Size(39, 36);
            this.button38.TabIndex = 60;
            this.button38.Text = "A3";
            this.button38.UseVisualStyleBackColor = true;
            // 
            // button39
            // 
            this.button39.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button39.Location = new System.Drawing.Point(375, 270);
            this.button39.Name = "button39";
            this.button39.Size = new System.Drawing.Size(39, 36);
            this.button39.TabIndex = 59;
            this.button39.Text = "A2";
            this.button39.UseVisualStyleBackColor = true;
            // 
            // button40
            // 
            this.button40.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button40.Location = new System.Drawing.Point(323, 270);
            this.button40.Name = "button40";
            this.button40.Size = new System.Drawing.Size(39, 36);
            this.button40.TabIndex = 58;
            this.button40.Text = "A1";
            this.button40.UseVisualStyleBackColor = true;
            // 
            // button21
            // 
            this.button21.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button21.Location = new System.Drawing.Point(819, 333);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(39, 36);
            this.button21.TabIndex = 57;
            this.button21.Text = "A10";
            this.button21.UseVisualStyleBackColor = true;
            // 
            // button22
            // 
            this.button22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button22.Location = new System.Drawing.Point(766, 333);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(39, 36);
            this.button22.TabIndex = 56;
            this.button22.Text = "A9";
            this.button22.UseVisualStyleBackColor = true;
            // 
            // button23
            // 
            this.button23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button23.Location = new System.Drawing.Point(713, 333);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(39, 36);
            this.button23.TabIndex = 55;
            this.button23.Text = "A8";
            this.button23.UseVisualStyleBackColor = true;
            // 
            // button24
            // 
            this.button24.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button24.Location = new System.Drawing.Point(661, 333);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(39, 36);
            this.button24.TabIndex = 54;
            this.button24.Text = "A7";
            this.button24.UseVisualStyleBackColor = true;
            // 
            // button25
            // 
            this.button25.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button25.Location = new System.Drawing.Point(609, 333);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(39, 36);
            this.button25.TabIndex = 53;
            this.button25.Text = "A6";
            this.button25.UseVisualStyleBackColor = true;
            // 
            // button26
            // 
            this.button26.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button26.Location = new System.Drawing.Point(532, 333);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(39, 36);
            this.button26.TabIndex = 52;
            this.button26.Text = "A5";
            this.button26.UseVisualStyleBackColor = true;
            // 
            // button27
            // 
            this.button27.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button27.Location = new System.Drawing.Point(480, 333);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(39, 36);
            this.button27.TabIndex = 51;
            this.button27.Text = "A4";
            this.button27.UseVisualStyleBackColor = true;
            // 
            // button28
            // 
            this.button28.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button28.Location = new System.Drawing.Point(427, 333);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(39, 36);
            this.button28.TabIndex = 50;
            this.button28.Text = "A3";
            this.button28.UseVisualStyleBackColor = true;
            // 
            // button29
            // 
            this.button29.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button29.Location = new System.Drawing.Point(375, 333);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(39, 36);
            this.button29.TabIndex = 49;
            this.button29.Text = "A2";
            this.button29.UseVisualStyleBackColor = true;
            // 
            // button30
            // 
            this.button30.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button30.Location = new System.Drawing.Point(323, 333);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(39, 36);
            this.button30.TabIndex = 48;
            this.button30.Text = "A1";
            this.button30.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.Location = new System.Drawing.Point(819, 398);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(39, 36);
            this.button6.TabIndex = 47;
            this.button6.Text = "A10";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            this.button7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.Location = new System.Drawing.Point(766, 398);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(39, 36);
            this.button7.TabIndex = 46;
            this.button7.Text = "A9";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // button13
            // 
            this.button13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button13.Location = new System.Drawing.Point(713, 398);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(39, 36);
            this.button13.TabIndex = 45;
            this.button13.Text = "A8";
            this.button13.UseVisualStyleBackColor = true;
            // 
            // button14
            // 
            this.button14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button14.Location = new System.Drawing.Point(661, 398);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(39, 36);
            this.button14.TabIndex = 44;
            this.button14.Text = "A7";
            this.button14.UseVisualStyleBackColor = true;
            // 
            // button15
            // 
            this.button15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button15.Location = new System.Drawing.Point(609, 398);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(39, 36);
            this.button15.TabIndex = 43;
            this.button15.Text = "A6";
            this.button15.UseVisualStyleBackColor = true;
            // 
            // button16
            // 
            this.button16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button16.Location = new System.Drawing.Point(532, 398);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(39, 36);
            this.button16.TabIndex = 42;
            this.button16.Text = "A5";
            this.button16.UseVisualStyleBackColor = true;
            // 
            // button17
            // 
            this.button17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button17.Location = new System.Drawing.Point(480, 398);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(39, 36);
            this.button17.TabIndex = 41;
            this.button17.Text = "A4";
            this.button17.UseVisualStyleBackColor = true;
            // 
            // button18
            // 
            this.button18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button18.Location = new System.Drawing.Point(427, 398);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(39, 36);
            this.button18.TabIndex = 40;
            this.button18.Text = "A3";
            this.button18.UseVisualStyleBackColor = true;
            // 
            // button19
            // 
            this.button19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button19.Location = new System.Drawing.Point(375, 398);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(39, 36);
            this.button19.TabIndex = 39;
            this.button19.Text = "A2";
            this.button19.UseVisualStyleBackColor = true;
            // 
            // button20
            // 
            this.button20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button20.Location = new System.Drawing.Point(323, 398);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(39, 36);
            this.button20.TabIndex = 38;
            this.button20.Text = "A1";
            this.button20.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            this.button9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.Location = new System.Drawing.Point(819, 457);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(39, 36);
            this.button9.TabIndex = 37;
            this.button9.Text = "A10";
            this.button9.UseVisualStyleBackColor = true;
            // 
            // button10
            // 
            this.button10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button10.Location = new System.Drawing.Point(766, 457);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(39, 36);
            this.button10.TabIndex = 36;
            this.button10.Text = "A9";
            this.button10.UseVisualStyleBackColor = true;
            // 
            // button11
            // 
            this.button11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button11.Location = new System.Drawing.Point(713, 457);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(39, 36);
            this.button11.TabIndex = 35;
            this.button11.Text = "A8";
            this.button11.UseVisualStyleBackColor = true;
            // 
            // button12
            // 
            this.button12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button12.Location = new System.Drawing.Point(661, 457);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(39, 36);
            this.button12.TabIndex = 34;
            this.button12.Text = "A7";
            this.button12.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.Location = new System.Drawing.Point(609, 457);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(39, 36);
            this.button5.TabIndex = 33;
            this.button5.Text = "A6";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            this.button8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.Location = new System.Drawing.Point(532, 457);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(39, 36);
            this.button8.TabIndex = 30;
            this.button8.Text = "A5";
            this.button8.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(480, 457);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(39, 36);
            this.button3.TabIndex = 29;
            this.button3.Text = "A4";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(427, 457);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(39, 36);
            this.button4.TabIndex = 28;
            this.button4.Text = "A3";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(375, 457);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(39, 36);
            this.button2.TabIndex = 27;
            this.button2.Text = "A2";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Franklin Gothic Medium", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(564, 168);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 24);
            this.label4.TabIndex = 26;
            this.label4.Text = "Seat";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(323, 457);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(39, 36);
            this.button1.TabIndex = 25;
            this.button1.Text = "A1";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Franklin Gothic Medium", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(113, 503);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(112, 24);
            this.label3.TabIndex = 24;
            this.label3.Text = "Rp. 35.000";
            // 
            // cbTime
            // 
            this.cbTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbTime.FormattingEnabled = true;
            this.cbTime.Items.AddRange(new object[] {
            "12:00",
            "14:15",
            "16:30",
            "18:45",
            "21:00"});
            this.cbTime.Location = new System.Drawing.Point(748, 134);
            this.cbTime.Name = "cbTime";
            this.cbTime.Size = new System.Drawing.Size(110, 24);
            this.cbTime.TabIndex = 23;
            this.cbTime.SelectedIndexChanged += new System.EventHandler(this.cbTime_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Franklin Gothic Medium", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(677, 134);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 24);
            this.label2.TabIndex = 22;
            this.label2.Text = "Time";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Franklin Gothic Medium", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(319, 134);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 24);
            this.label1.TabIndex = 21;
            this.label1.Text = "Date";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.Location = new System.Drawing.Point(390, 135);
            this.dateTimePicker1.MinDate = new System.DateTime(2020, 1, 6, 0, 0, 0, 0);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(245, 23);
            this.dateTimePicker1.TabIndex = 20;
            this.dateTimePicker1.Value = new System.DateTime(2020, 1, 6, 0, 0, 0, 0);
            // 
            // imgMovie
            // 
            this.imgMovie.BackColor = System.Drawing.Color.Transparent;
            this.imgMovie.BackgroundImage = global::IndoxMovie.Properties.Resources.JUMANJI___THE_NEXT_LEVEL;
            this.imgMovie.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.imgMovie.FlatAppearance.BorderSize = 0;
            this.imgMovie.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.imgMovie.ForeColor = System.Drawing.Color.Transparent;
            this.imgMovie.Location = new System.Drawing.Point(31, 134);
            this.imgMovie.Name = "imgMovie";
            this.imgMovie.Size = new System.Drawing.Size(263, 359);
            this.imgMovie.TabIndex = 19;
            this.imgMovie.UseVisualStyleBackColor = false;
            // 
            // panelDetailOrder
            // 
            this.panelDetailOrder.BackgroundImage = global::IndoxMovie.Properties.Resources.bg_detailorder;
            this.panelDetailOrder.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panelDetailOrder.Controls.Add(this.btnConfirm);
            this.panelDetailOrder.Controls.Add(this.btnCancel);
            this.panelDetailOrder.Controls.Add(this.label16);
            this.panelDetailOrder.Controls.Add(this.label17);
            this.panelDetailOrder.Controls.Add(this.label18);
            this.panelDetailOrder.Controls.Add(this.label19);
            this.panelDetailOrder.Controls.Add(this.label20);
            this.panelDetailOrder.Controls.Add(this.txtTime);
            this.panelDetailOrder.Controls.Add(this.txtDateTicket);
            this.panelDetailOrder.Controls.Add(this.txtSeat);
            this.panelDetailOrder.Controls.Add(this.txtPrice);
            this.panelDetailOrder.Controls.Add(this.txtTitle);
            this.panelDetailOrder.Controls.Add(this.label10);
            this.panelDetailOrder.Controls.Add(this.label9);
            this.panelDetailOrder.Controls.Add(this.label8);
            this.panelDetailOrder.Controls.Add(this.label7);
            this.panelDetailOrder.Controls.Add(this.label6);
            this.panelDetailOrder.Controls.Add(this.imgDetailOrder);
            this.panelDetailOrder.Location = new System.Drawing.Point(0, 0);
            this.panelDetailOrder.Margin = new System.Windows.Forms.Padding(0);
            this.panelDetailOrder.Name = "panelDetailOrder";
            this.panelDetailOrder.Size = new System.Drawing.Size(885, 565);
            this.panelDetailOrder.TabIndex = 13;
            this.panelDetailOrder.Visible = false;
            // 
            // btnConfirm
            // 
            this.btnConfirm.BackColor = System.Drawing.Color.Transparent;
            this.btnConfirm.BackgroundImage = global::IndoxMovie.Properties.Resources.btn_confirm;
            this.btnConfirm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnConfirm.FlatAppearance.BorderSize = 0;
            this.btnConfirm.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnConfirm.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnConfirm.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnConfirm.ForeColor = System.Drawing.Color.Transparent;
            this.btnConfirm.Location = new System.Drawing.Point(276, 427);
            this.btnConfirm.Name = "btnConfirm";
            this.btnConfirm.Size = new System.Drawing.Size(150, 47);
            this.btnConfirm.TabIndex = 41;
            this.btnConfirm.UseVisualStyleBackColor = false;
            this.btnConfirm.Click += new System.EventHandler(this.btnConfirm_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.Color.Transparent;
            this.btnCancel.BackgroundImage = global::IndoxMovie.Properties.Resources.btn_cancel;
            this.btnCancel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCancel.FlatAppearance.BorderSize = 0;
            this.btnCancel.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnCancel.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancel.ForeColor = System.Drawing.Color.Transparent;
            this.btnCancel.Location = new System.Drawing.Point(95, 427);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(150, 47);
            this.btnCancel.TabIndex = 40;
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.Transparent;
            this.label16.Font = new System.Drawing.Font("Franklin Gothic Medium", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(136, 353);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(16, 24);
            this.label16.TabIndex = 39;
            this.label16.Text = ":";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.Transparent;
            this.label17.Font = new System.Drawing.Font("Franklin Gothic Medium", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(136, 304);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(16, 24);
            this.label17.TabIndex = 38;
            this.label17.Text = ":";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.Transparent;
            this.label18.Font = new System.Drawing.Font("Franklin Gothic Medium", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(136, 257);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(16, 24);
            this.label18.TabIndex = 37;
            this.label18.Text = ":";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.Transparent;
            this.label19.Font = new System.Drawing.Font("Franklin Gothic Medium", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(136, 211);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(16, 24);
            this.label19.TabIndex = 36;
            this.label19.Text = ":";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.Color.Transparent;
            this.label20.Font = new System.Drawing.Font("Franklin Gothic Medium", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(136, 166);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(16, 24);
            this.label20.TabIndex = 35;
            this.label20.Text = ":";
            // 
            // txtTime
            // 
            this.txtTime.AutoSize = true;
            this.txtTime.BackColor = System.Drawing.Color.Transparent;
            this.txtTime.Font = new System.Drawing.Font("Franklin Gothic Medium", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTime.Location = new System.Drawing.Point(152, 354);
            this.txtTime.Name = "txtTime";
            this.txtTime.Size = new System.Drawing.Size(59, 24);
            this.txtTime.TabIndex = 34;
            this.txtTime.Text = "12:00";
            // 
            // txtDateTicket
            // 
            this.txtDateTicket.AutoSize = true;
            this.txtDateTicket.BackColor = System.Drawing.Color.Transparent;
            this.txtDateTicket.Font = new System.Drawing.Font("Franklin Gothic Medium", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDateTicket.Location = new System.Drawing.Point(152, 305);
            this.txtDateTicket.Name = "txtDateTicket";
            this.txtDateTicket.Size = new System.Drawing.Size(114, 24);
            this.txtDateTicket.TabIndex = 33;
            this.txtDateTicket.Text = "2020/01/01";
            // 
            // txtSeat
            // 
            this.txtSeat.AutoSize = true;
            this.txtSeat.BackColor = System.Drawing.Color.Transparent;
            this.txtSeat.Font = new System.Drawing.Font("Franklin Gothic Medium", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSeat.Location = new System.Drawing.Point(152, 258);
            this.txtSeat.Name = "txtSeat";
            this.txtSeat.Size = new System.Drawing.Size(128, 24);
            this.txtSeat.TabIndex = 32;
            this.txtSeat.Text = "A1, A2, A3, A4";
            // 
            // txtPrice
            // 
            this.txtPrice.AutoSize = true;
            this.txtPrice.BackColor = System.Drawing.Color.Transparent;
            this.txtPrice.Font = new System.Drawing.Font("Franklin Gothic Medium", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPrice.Location = new System.Drawing.Point(152, 212);
            this.txtPrice.Name = "txtPrice";
            this.txtPrice.Size = new System.Drawing.Size(65, 24);
            this.txtPrice.TabIndex = 31;
            this.txtPrice.Text = "35000";
            // 
            // txtTitle
            // 
            this.txtTitle.AutoSize = true;
            this.txtTitle.BackColor = System.Drawing.Color.Transparent;
            this.txtTitle.Font = new System.Drawing.Font("Franklin Gothic Medium", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTitle.Location = new System.Drawing.Point(152, 167);
            this.txtTitle.Name = "txtTitle";
            this.txtTitle.Size = new System.Drawing.Size(220, 24);
            this.txtTitle.TabIndex = 30;
            this.txtTitle.Text = "JUMANJI: THE NEXT LEVEL";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Franklin Gothic Medium", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(71, 354);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(55, 24);
            this.label10.TabIndex = 29;
            this.label10.Text = "Time";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Franklin Gothic Medium", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(71, 305);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(52, 24);
            this.label9.TabIndex = 28;
            this.label9.Text = "Date";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Franklin Gothic Medium", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(71, 258);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(51, 24);
            this.label8.TabIndex = 27;
            this.label8.Text = "Seat";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Franklin Gothic Medium", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(71, 212);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(56, 24);
            this.label7.TabIndex = 26;
            this.label7.Text = "Price";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Franklin Gothic Medium", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(71, 167);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(50, 24);
            this.label6.TabIndex = 25;
            this.label6.Text = "Title";
            // 
            // imgDetailOrder
            // 
            this.imgDetailOrder.BackColor = System.Drawing.Color.Transparent;
            this.imgDetailOrder.BackgroundImage = global::IndoxMovie.Properties.Resources.JUMANJI___THE_NEXT_LEVEL;
            this.imgDetailOrder.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.imgDetailOrder.FlatAppearance.BorderSize = 0;
            this.imgDetailOrder.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.imgDetailOrder.ForeColor = System.Drawing.Color.Transparent;
            this.imgDetailOrder.Location = new System.Drawing.Point(542, 134);
            this.imgDetailOrder.Name = "imgDetailOrder";
            this.imgDetailOrder.Size = new System.Drawing.Size(263, 359);
            this.imgDetailOrder.TabIndex = 19;
            this.imgDetailOrder.UseVisualStyleBackColor = false;
            // 
            // formDashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::IndoxMovie.Properties.Resources.bg_listFilm;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(884, 562);
            this.Controls.Add(this.panelListFilm);
            this.Controls.Add(this.panelDetailOrder);
            this.Controls.Add(this.panelOrder);
            this.Name = "formDashboard";
            this.Text = "formDashboard";
            this.panelListFilm.ResumeLayout(false);
            this.panelOrder.ResumeLayout(false);
            this.panelOrder.PerformLayout();
            this.panelDetailOrder.ResumeLayout(false);
            this.panelDetailOrder.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelListFilm;
        public System.Windows.Forms.Button imgJumanji;
        public System.Windows.Forms.Button imgDabangg3;
        public System.Windows.Forms.Button imgUnderwater;
        public System.Windows.Forms.Button imgRasuk2;
        public System.Windows.Forms.Button imgJoker;
        public System.Windows.Forms.Button imgBlackChristmas;
        public System.Windows.Forms.Button imgFrozen2;
        public System.Windows.Forms.Button imgJeritanMalam;
        private System.Windows.Forms.Panel panelOrder;
        public System.Windows.Forms.Button imgMovie;
        private System.Windows.Forms.ComboBox cbTime;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.Button button42;
        private System.Windows.Forms.Button button43;
        private System.Windows.Forms.Button button44;
        private System.Windows.Forms.Button button45;
        private System.Windows.Forms.Button button46;
        private System.Windows.Forms.Button button47;
        private System.Windows.Forms.Button button48;
        private System.Windows.Forms.Button button49;
        private System.Windows.Forms.Button button50;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.Button button37;
        private System.Windows.Forms.Button button38;
        private System.Windows.Forms.Button button39;
        private System.Windows.Forms.Button button40;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panelDetailOrder;
        public System.Windows.Forms.Button imgDetailOrder;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label txtTime;
        private System.Windows.Forms.Label txtDateTicket;
        private System.Windows.Forms.Label txtSeat;
        private System.Windows.Forms.Label txtPrice;
        private System.Windows.Forms.Label txtTitle;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        public System.Windows.Forms.Button btnCancel;
        public System.Windows.Forms.Button btnConfirm;
        public System.Windows.Forms.Button button51;
        public System.Windows.Forms.Button button52;

    }
}