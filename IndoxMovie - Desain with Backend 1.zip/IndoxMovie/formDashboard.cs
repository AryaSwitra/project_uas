﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace IndoxMovie
{
    public partial class formDashboard : Form
    {
        OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\DEATA\Documents\IndoxMovie\IndoxMovie\indoxMovie.mdb");

        public formDashboard()
        {
            InitializeComponent();
        }

        private void imgJumanji_Click_1(object sender, EventArgs e)
        {
            panelListFilm.Visible = false;
            panelOrder.Visible = true;
            imgMovie.BackgroundImage = IndoxMovie.Properties.Resources.JUMANJI___THE_NEXT_LEVEL;
            imgDetailOrder.BackgroundImage = IndoxMovie.Properties.Resources.JUMANJI___THE_NEXT_LEVEL;
            txtTitle.Text = "JUMANJI: THE NEXT LEVEL";
        }

        private void imgJeritanMalam_Click(object sender, EventArgs e)
        {
            panelListFilm.Visible = false;
            panelOrder.Visible = true;
            imgMovie.BackgroundImage = IndoxMovie.Properties.Resources.JERITAN_MALAM;
            imgDetailOrder.BackgroundImage = IndoxMovie.Properties.Resources.JERITAN_MALAM;
            txtTitle.Text = "JERITAN MALAM";
        }

        private void imgFrozen2_Click(object sender, EventArgs e)
        {
            panelListFilm.Visible = false;
            panelOrder.Visible = true;
            imgMovie.BackgroundImage = IndoxMovie.Properties.Resources.FROZEN_2;
            imgDetailOrder.BackgroundImage = IndoxMovie.Properties.Resources.FROZEN_2;
            txtTitle.Text = "FROZEN 2";
        }

        private void imgBlackChristmas_Click(object sender, EventArgs e)
        {
            panelListFilm.Visible = false;
            panelOrder.Visible = true;
            imgMovie.BackgroundImage = IndoxMovie.Properties.Resources.BLACK_CHRISTMAS;
            imgDetailOrder.BackgroundImage = IndoxMovie.Properties.Resources.BLACK_CHRISTMAS;
            txtTitle.Text = "BLACK CHRISTMAS";
        }

        private void imgJoker_Click_1(object sender, EventArgs e)
        {
            panelListFilm.Visible = false;
            panelOrder.Visible = true;
            imgMovie.BackgroundImage = IndoxMovie.Properties.Resources.JOKER;
            imgDetailOrder.BackgroundImage = IndoxMovie.Properties.Resources.JOKER;
            txtTitle.Text = "JOKER";
        }

        private void imgRasuk2_Click(object sender, EventArgs e)
        {
            panelListFilm.Visible = false;
            panelOrder.Visible = true;
            imgMovie.BackgroundImage = IndoxMovie.Properties.Resources.RASUK_2;
            imgDetailOrder.BackgroundImage = IndoxMovie.Properties.Resources.RASUK_2;
            txtTitle.Text = "RASUK 2";
        }

        private void imgUnderwater_Click(object sender, EventArgs e)
        {
            panelListFilm.Visible = false;
            panelOrder.Visible = true;
            imgMovie.BackgroundImage = IndoxMovie.Properties.Resources.UNDERWATER;
            imgDetailOrder.BackgroundImage = IndoxMovie.Properties.Resources.UNDERWATER;
            txtTitle.Text = "UNDERWATER";
        }

        private void imgDabangg3_Click(object sender, EventArgs e)
        {
            panelListFilm.Visible = false;
            panelOrder.Visible = true;
            imgMovie.BackgroundImage = IndoxMovie.Properties.Resources.DABANGG_3;
            imgDetailOrder.BackgroundImage = IndoxMovie.Properties.Resources.DABANGG_3;
            txtTitle.Text = "DABANGG 3";
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            panelDetailOrder.Visible = false;
            panelOrder.Visible = true;
        }

        private void button52_Click(object sender, EventArgs e)
        {
            panelOrder.Visible = false;
            panelListFilm.Visible = true;
        }

        private void button51_Click(object sender, EventArgs e)
        {
            panelOrder.Visible = false;
            panelDetailOrder.Visible = true;
        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            con.Open();
            OleDbCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "INSERT INTO history (`date_order`, `title`, `seat`, `date_ticket`, `time`, `price`) values ('" + DateTime.Now + "','" + txtTitle.Text + "','" + txtSeat.Text + "','" + DateTime.Now + "','" + txtTime.Text + "','" + txtPrice.Text + "')";
            cmd.ExecuteNonQuery();
            con.Close();

            formInvoice formInvoice = new formInvoice();
            formInvoice.Show();
            this.Hide();
        }

        private void cbTime_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (cbTime.Text == "12:00")
            {
                txtTime.Text = "12:00";
            } else
                if (cbTime.Text == "14:15")
            {
                txtTime.Text = "14:15";
            } else
                if (cbTime.Text == "16:30")
            {
                txtTime.Text = "16:30";
            } else
                if (cbTime.Text == "18:45")
            {
                txtTime.Text = "18:45";
            } else
                if (cbTime.Text == "21:00")
            {
                txtTime.Text = "21:00";
            }
        }

    }
}
