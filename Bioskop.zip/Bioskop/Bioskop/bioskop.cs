﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Bioskop
{
    class bioskop
    {
        private string invoice, judul, tanggal, waktu, seat, harga;
        private DateTime tanggal2;

        public DateTime Tanggal2
        {
            get { return tanggal2; }
            set { tanggal2 = value; }
        }

        public string Harga
        {
            get { return harga; }
            set { harga = value; }
        }

        public string Seat
        {
            get { return seat; }
            set { seat = value; }
        }

        public string Waktu
        {
            get { return waktu; }
            set { waktu = value; }
        }

        public string Tanggal
        {
            get { return tanggal; }
            set { tanggal = value; }
        }

        public string Judul
        {
            get { return judul; }
            set { judul = value; }
        }

        public string Invoice
        {
            get { return invoice; }
            set { invoice = value; }
        }

    }
}
