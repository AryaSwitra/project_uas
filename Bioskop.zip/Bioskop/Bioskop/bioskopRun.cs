﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MySql.Data.MySqlClient;
using System.Data;

namespace Bioskop
{
    class bioskopRun
    {
         private MySqlCommand perintah = null;

         string konfigurasi = "Server=localhost;Port=3306;UID=root;PWD=;Database=bioskop";
         MySqlConnection koneksi = new MySqlConnection();
 
        public bioskopRun()
         {
         koneksi.ConnectionString = konfigurasi;
         }
 
        public DataSet getData()
         {
         DataSet ds = new DataSet();
         try
         {
         koneksi.Open();
         perintah = new MySqlCommand();
         perintah.Connection = koneksi;
         perintah.CommandType = CommandType.Text;
         perintah.CommandText = "SELECT invoice,judul,tanggal,waktu,seat,harga FROM history";
         MySqlDataAdapter mdap = new MySqlDataAdapter(perintah);
         mdap.Fill(ds, "history");
         koneksi.Close();
         }catch(MySqlException){
         }
         return ds;
         }

         public bool insertData(bioskop m)
         {
         Boolean stat = false;
         try
         {
         koneksi.Open();
         perintah = new MySqlCommand();
         perintah.Connection = koneksi;
         perintah.CommandType = CommandType.Text;
         perintah.CommandText = "INSERT INTO history VALUES ('" + 2 + "','" + m.Judul + "','"+ m.Tanggal + "','" + m.Waktu + "','" + m.Seat + "','" + m.Harga + "')";
         perintah.ExecuteNonQuery();
         stat = true;
         koneksi.Close();
         }
         catch (MySqlException) { }
 
         return stat;
         }

    }
}
