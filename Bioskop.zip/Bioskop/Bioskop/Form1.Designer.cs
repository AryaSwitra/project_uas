﻿namespace Bioskop
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.login = new System.Windows.Forms.Panel();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtUsername = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.dashboard = new System.Windows.Forms.Panel();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.detail = new System.Windows.Forms.Panel();
            this.button17 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.comboJam = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.comboHari = new System.Windows.Forms.ComboBox();
            this.button5 = new System.Windows.Forms.Button();
            this.confirm = new System.Windows.Forms.Panel();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.btnBeliTiket = new System.Windows.Forms.Button();
            this.hargaTiket = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.pilihanKursi = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.pilihanFilm = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.pilihanJam = new System.Windows.Forms.Label();
            this.pilihanHari = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.history = new System.Windows.Forms.Panel();
            this.login.SuspendLayout();
            this.dashboard.SuspendLayout();
            this.detail.SuspendLayout();
            this.confirm.SuspendLayout();
            this.SuspendLayout();
            // 
            // login
            // 
            this.login.Controls.Add(this.txtPassword);
            this.login.Controls.Add(this.label2);
            this.login.Controls.Add(this.txtUsername);
            this.login.Controls.Add(this.button1);
            this.login.Controls.Add(this.label1);
            this.login.Location = new System.Drawing.Point(-2, -2);
            this.login.Name = "login";
            this.login.Size = new System.Drawing.Size(789, 468);
            this.login.TabIndex = 0;
            this.login.Paint += new System.Windows.Forms.PaintEventHandler(this.login_Paint);
            // 
            // txtPassword
            // 
            this.txtPassword.Location = new System.Drawing.Point(375, 220);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(100, 20);
            this.txtPassword.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(314, 220);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "Password";
            // 
            // txtUsername
            // 
            this.txtUsername.Location = new System.Drawing.Point(375, 191);
            this.txtUsername.Name = "txtUsername";
            this.txtUsername.Size = new System.Drawing.Size(100, 20);
            this.txtUsername.TabIndex = 1;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(317, 255);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(158, 23);
            this.button1.TabIndex = 3;
            this.button1.Text = "LOGIN";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(314, 194);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Username";
            // 
            // dashboard
            // 
            this.dashboard.Controls.Add(this.button3);
            this.dashboard.Controls.Add(this.button2);
            this.dashboard.Controls.Add(this.label4);
            this.dashboard.Location = new System.Drawing.Point(-2, -3);
            this.dashboard.Name = "dashboard";
            this.dashboard.Size = new System.Drawing.Size(789, 468);
            this.dashboard.TabIndex = 1;
            this.dashboard.Visible = false;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(151, 47);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 145);
            this.button3.TabIndex = 7;
            this.button3.Text = "Film Kedua";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(48, 47);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 145);
            this.button2.TabIndex = 6;
            this.button2.Text = "Film Pertama";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(324, 221);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(142, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "Welcome to Mobile Legends";
            // 
            // detail
            // 
            this.detail.Controls.Add(this.button17);
            this.detail.Controls.Add(this.label6);
            this.detail.Controls.Add(this.button14);
            this.detail.Controls.Add(this.button15);
            this.detail.Controls.Add(this.button16);
            this.detail.Controls.Add(this.button11);
            this.detail.Controls.Add(this.button12);
            this.detail.Controls.Add(this.button13);
            this.detail.Controls.Add(this.button8);
            this.detail.Controls.Add(this.button9);
            this.detail.Controls.Add(this.button10);
            this.detail.Controls.Add(this.button7);
            this.detail.Controls.Add(this.button6);
            this.detail.Controls.Add(this.button4);
            this.detail.Controls.Add(this.label5);
            this.detail.Controls.Add(this.comboJam);
            this.detail.Controls.Add(this.label3);
            this.detail.Controls.Add(this.comboHari);
            this.detail.Controls.Add(this.button5);
            this.detail.Location = new System.Drawing.Point(6, 5);
            this.detail.Name = "detail";
            this.detail.Size = new System.Drawing.Size(789, 468);
            this.detail.TabIndex = 2;
            this.detail.Visible = false;
            // 
            // button17
            // 
            this.button17.Location = new System.Drawing.Point(448, 357);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(117, 23);
            this.button17.TabIndex = 24;
            this.button17.Text = "Pesan Tiket";
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new System.EventHandler(this.button17_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(488, 151);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(40, 13);
            this.label6.TabIndex = 23;
            this.label6.Text = "KURSI";
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(630, 258);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(34, 23);
            this.button14.TabIndex = 22;
            this.button14.Text = "B6";
            this.button14.UseVisualStyleBackColor = true;
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(577, 258);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(34, 23);
            this.button15.TabIndex = 21;
            this.button15.Text = "B5";
            this.button15.UseVisualStyleBackColor = true;
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(526, 258);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(34, 23);
            this.button16.TabIndex = 20;
            this.button16.Text = "B4";
            this.button16.UseVisualStyleBackColor = true;
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(630, 203);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(34, 23);
            this.button11.TabIndex = 19;
            this.button11.Text = "A6";
            this.button11.UseVisualStyleBackColor = true;
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(577, 203);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(34, 23);
            this.button12.TabIndex = 18;
            this.button12.Text = "A5";
            this.button12.UseVisualStyleBackColor = true;
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(526, 203);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(34, 23);
            this.button13.TabIndex = 17;
            this.button13.Text = "A4";
            this.button13.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(451, 258);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(34, 23);
            this.button8.TabIndex = 16;
            this.button8.Text = "B3";
            this.button8.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(398, 258);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(34, 23);
            this.button9.TabIndex = 15;
            this.button9.Text = "B2";
            this.button9.UseVisualStyleBackColor = true;
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(347, 258);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(34, 23);
            this.button10.TabIndex = 14;
            this.button10.Text = "B1";
            this.button10.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(451, 203);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(34, 23);
            this.button7.TabIndex = 13;
            this.button7.Text = "A3";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(398, 203);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(34, 23);
            this.button6.TabIndex = 12;
            this.button6.Text = "A2";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(347, 203);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(34, 23);
            this.button4.TabIndex = 11;
            this.button4.Text = "A1";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(548, 71);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(28, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "JAM";
            // 
            // comboJam
            // 
            this.comboJam.FormattingEnabled = true;
            this.comboJam.Items.AddRange(new object[] {
            "12:00",
            "14:15",
            "16:30",
            "18:45",
            "21:00"});
            this.comboJam.Location = new System.Drawing.Point(599, 68);
            this.comboJam.Name = "comboJam";
            this.comboJam.Size = new System.Drawing.Size(121, 21);
            this.comboJam.TabIndex = 9;
            this.comboJam.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(265, 71);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(33, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "HARI";
            // 
            // comboHari
            // 
            this.comboHari.FormattingEnabled = true;
            this.comboHari.Items.AddRange(new object[] {
            "Senin",
            "Selasa",
            "Rabu",
            "Kamis",
            "Jumat",
            "Sabtu",
            "Minggu"});
            this.comboHari.Location = new System.Drawing.Point(319, 68);
            this.comboHari.Name = "comboHari";
            this.comboHari.Size = new System.Drawing.Size(121, 21);
            this.comboHari.TabIndex = 7;
            this.comboHari.SelectedIndexChanged += new System.EventHandler(this.comboHari_SelectedIndexChanged);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(40, 65);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(205, 315);
            this.button5.TabIndex = 6;
            this.button5.Text = "Gambar Film Pertama";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // confirm
            // 
            this.confirm.Controls.Add(this.dateTimePicker1);
            this.confirm.Controls.Add(this.btnBeliTiket);
            this.confirm.Controls.Add(this.hargaTiket);
            this.confirm.Controls.Add(this.label10);
            this.confirm.Controls.Add(this.pilihanKursi);
            this.confirm.Controls.Add(this.label14);
            this.confirm.Controls.Add(this.pilihanFilm);
            this.confirm.Controls.Add(this.label12);
            this.confirm.Controls.Add(this.pilihanJam);
            this.confirm.Controls.Add(this.pilihanHari);
            this.confirm.Controls.Add(this.label8);
            this.confirm.Controls.Add(this.label7);
            this.confirm.Location = new System.Drawing.Point(14, 13);
            this.confirm.Name = "confirm";
            this.confirm.Size = new System.Drawing.Size(789, 468);
            this.confirm.TabIndex = 3;
            this.confirm.Visible = false;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(244, 54);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker1.TabIndex = 11;
            // 
            // btnBeliTiket
            // 
            this.btnBeliTiket.Location = new System.Drawing.Point(32, 200);
            this.btnBeliTiket.Name = "btnBeliTiket";
            this.btnBeliTiket.Size = new System.Drawing.Size(108, 23);
            this.btnBeliTiket.TabIndex = 10;
            this.btnBeliTiket.Text = "Beli Tiket";
            this.btnBeliTiket.UseVisualStyleBackColor = true;
            this.btnBeliTiket.Click += new System.EventHandler(this.btnBeliTiket_Click);
            // 
            // hargaTiket
            // 
            this.hargaTiket.AutoSize = true;
            this.hargaTiket.Location = new System.Drawing.Point(81, 163);
            this.hargaTiket.Name = "hargaTiket";
            this.hargaTiket.Size = new System.Drawing.Size(37, 13);
            this.hargaTiket.TabIndex = 9;
            this.hargaTiket.Text = "35000";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(29, 163);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(45, 13);
            this.label10.TabIndex = 8;
            this.label10.Text = "HARGA";
            // 
            // pilihanKursi
            // 
            this.pilihanKursi.AutoSize = true;
            this.pilihanKursi.Location = new System.Drawing.Point(81, 127);
            this.pilihanKursi.Name = "pilihanKursi";
            this.pilihanKursi.Size = new System.Drawing.Size(64, 13);
            this.pilihanKursi.TabIndex = 7;
            this.pilihanKursi.Text = "Pilihan Kursi";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(29, 127);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(40, 13);
            this.label14.TabIndex = 6;
            this.label14.Text = "KURSI";
            // 
            // pilihanFilm
            // 
            this.pilihanFilm.AutoSize = true;
            this.pilihanFilm.Location = new System.Drawing.Point(81, 31);
            this.pilihanFilm.Name = "pilihanFilm";
            this.pilihanFilm.Size = new System.Drawing.Size(59, 13);
            this.pilihanFilm.TabIndex = 5;
            this.pilihanFilm.Text = "Pilihan Film";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(29, 31);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(31, 13);
            this.label12.TabIndex = 4;
            this.label12.Text = "FILM";
            // 
            // pilihanJam
            // 
            this.pilihanJam.AutoSize = true;
            this.pilihanJam.Location = new System.Drawing.Point(81, 92);
            this.pilihanJam.Name = "pilihanJam";
            this.pilihanJam.Size = new System.Drawing.Size(60, 13);
            this.pilihanJam.TabIndex = 3;
            this.pilihanJam.Text = "Pilihan Jam";
            // 
            // pilihanHari
            // 
            this.pilihanHari.AutoSize = true;
            this.pilihanHari.Location = new System.Drawing.Point(81, 62);
            this.pilihanHari.Name = "pilihanHari";
            this.pilihanHari.Size = new System.Drawing.Size(60, 13);
            this.pilihanHari.TabIndex = 2;
            this.pilihanHari.Text = "Pilihan Hari";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(29, 92);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(28, 13);
            this.label8.TabIndex = 1;
            this.label8.Text = "JAM";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(29, 62);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(33, 13);
            this.label7.TabIndex = 0;
            this.label7.Text = "HARI";
            // 
            // history
            // 
            this.history.Location = new System.Drawing.Point(1, 0);
            this.history.Name = "history";
            this.history.Size = new System.Drawing.Size(789, 468);
            this.history.TabIndex = 4;
            this.history.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 462);
            this.Controls.Add(this.history);
            this.Controls.Add(this.confirm);
            this.Controls.Add(this.detail);
            this.Controls.Add(this.dashboard);
            this.Controls.Add(this.login);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.login.ResumeLayout(false);
            this.login.PerformLayout();
            this.dashboard.ResumeLayout(false);
            this.dashboard.PerformLayout();
            this.detail.ResumeLayout(false);
            this.detail.PerformLayout();
            this.confirm.ResumeLayout(false);
            this.confirm.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel login;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtUsername;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel dashboard;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Panel detail;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox comboJam;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox comboHari;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Panel confirm;
        private System.Windows.Forms.Button btnBeliTiket;
        private System.Windows.Forms.Label hargaTiket;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label pilihanKursi;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label pilihanFilm;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label pilihanJam;
        private System.Windows.Forms.Label pilihanHari;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Panel history;
    }
}

