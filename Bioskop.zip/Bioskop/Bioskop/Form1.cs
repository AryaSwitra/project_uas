﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Bioskop
{
    public partial class Form1 : Form
    {
        koneksi con = new koneksi();
        string id, username, password;
        string[] contoh = new string[4] { "A1", "A2", "B1", "B2" };

        public Form1()
        {
            InitializeComponent();
        }

        bioskopRun md = new bioskopRun();

        private void login_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {

                if (txtUsername.Text != "" && txtPassword.Text != "")
                {

                    con.Open();
                    string query = "select id,username,password from kasir WHERE username ='" + txtUsername.Text + "' AND password ='" + txtPassword.Text + "'";
                    MySqlDataReader row;
                    row = con.ExecuteReader(query);
                    if (row.HasRows)
                    {
                        while (row.Read())
                        {
                            id = row["id"].ToString();
                            username = row["username"].ToString();
                            password = row["password"].ToString();
                        }

                        MessageBox.Show("Data found your username is " + username + " and your password is " + password);
                        login.Visible = false;
                        dashboard.Visible = true;
                    }
                    else
                    {
                        MessageBox.Show("Data not found", "Information");
                    }
                }
                else
                {
                    MessageBox.Show("Username or Password is empty", "Information");
                }
            }
            catch
            {
                MessageBox.Show("Connection Error", "Information");
            }  
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboJam.Text == "12:00")
            {
                pilihanJam.Text = "12:00";
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            pilihanKursi.Text = "A1";
            button4.Enabled = false;
        }

        private void button5_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            dashboard.Visible = false;
            detail.Visible = true;
        }

        private void button17_Click(object sender, EventArgs e)
        {
            detail.Visible = false;
            confirm.Visible = true;
        }

        private void comboHari_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboHari.Text == "Senin")
            {
                pilihanHari.Text = "Senin";
            }
        }

        private void btnBeliTiket_Click(object sender, EventArgs e)
        {
            bioskop m = new bioskop();
            m.Judul = pilihanFilm.Text;
            m.Tanggal = dateTimePicker1.Value.ToString("yyyy-MM-dd");
            m.Waktu = pilihanJam.Text;
            m.Seat = pilihanKursi.Text;
            m.Harga = hargaTiket.Text;
            md.insertData(m);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }


    }
}
