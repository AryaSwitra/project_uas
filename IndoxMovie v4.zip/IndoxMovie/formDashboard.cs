﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;
using CrystalDecisions.CrystalReports.Engine;

namespace IndoxMovie
{
    public partial class formDashboard : Form
    {
        int newSeat = 0;
        int tiketPrice = 35000;
        int totalPrice, totalSeat;
        string Seat1, Seat2;

        OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\DEATA\Documents\IndoxMovie\IndoxMovie\indoxMovie.mdb");

        public formDashboard()
        {
            InitializeComponent();
            con.Open();
            OleDbCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "SELECT * FROM history ORDER BY invoice DESC";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            OleDbDataAdapter da = new OleDbDataAdapter(cmd);
            da.Fill(dt);
            dgHistory.DataSource = dt;
            con.Close();
        }


        private void imgJumanji_Click_1(object sender, EventArgs e)
        {
            panelListFilm.Visible = false;
            panelOrder.Visible = true;
            imgMovie.BackgroundImage = IndoxMovie.Properties.Resources.JUMANJI___THE_NEXT_LEVEL;
            imgDetailOrder.BackgroundImage = IndoxMovie.Properties.Resources.JUMANJI___THE_NEXT_LEVEL;
            txtTitle.Text = "JUMANJI: THE NEXT LEVEL";
        }

        private void imgJeritanMalam_Click(object sender, EventArgs e)
        {
            panelListFilm.Visible = false;
            panelOrder.Visible = true;
            imgMovie.BackgroundImage = IndoxMovie.Properties.Resources.JERITAN_MALAM;
            imgDetailOrder.BackgroundImage = IndoxMovie.Properties.Resources.JERITAN_MALAM;
            txtTitle.Text = "JERITAN MALAM";
        }

        private void imgFrozen2_Click(object sender, EventArgs e)
        {
            panelListFilm.Visible = false;
            panelOrder.Visible = true;
            imgMovie.BackgroundImage = IndoxMovie.Properties.Resources.FROZEN_2;
            imgDetailOrder.BackgroundImage = IndoxMovie.Properties.Resources.FROZEN_2;
            txtTitle.Text = "FROZEN 2";
        }

        private void imgBlackChristmas_Click(object sender, EventArgs e)
        {
            panelListFilm.Visible = false;
            panelOrder.Visible = true;
            imgMovie.BackgroundImage = IndoxMovie.Properties.Resources.BLACK_CHRISTMAS;
            imgDetailOrder.BackgroundImage = IndoxMovie.Properties.Resources.BLACK_CHRISTMAS;
            txtTitle.Text = "BLACK CHRISTMAS";
        }

        private void imgJoker_Click_1(object sender, EventArgs e)
        {
            panelListFilm.Visible = false;
            panelOrder.Visible = true;
            imgMovie.BackgroundImage = IndoxMovie.Properties.Resources.JOKER;
            imgDetailOrder.BackgroundImage = IndoxMovie.Properties.Resources.JOKER;
            txtTitle.Text = "JOKER";
        }

        private void imgRasuk2_Click(object sender, EventArgs e)
        {
            panelListFilm.Visible = false;
            panelOrder.Visible = true;
            imgMovie.BackgroundImage = IndoxMovie.Properties.Resources.RASUK_2;
            imgDetailOrder.BackgroundImage = IndoxMovie.Properties.Resources.RASUK_2;
            txtTitle.Text = "RASUK 2";
        }

        private void imgUnderwater_Click(object sender, EventArgs e)
        {
            panelListFilm.Visible = false;
            panelOrder.Visible = true;
            imgMovie.BackgroundImage = IndoxMovie.Properties.Resources.UNDERWATER;
            imgDetailOrder.BackgroundImage = IndoxMovie.Properties.Resources.UNDERWATER;
            txtTitle.Text = "UNDERWATER";
        }

        private void imgDabangg3_Click(object sender, EventArgs e)
        {
            panelListFilm.Visible = false;
            panelOrder.Visible = true;
            imgMovie.BackgroundImage = IndoxMovie.Properties.Resources.DABANGG_3;
            imgDetailOrder.BackgroundImage = IndoxMovie.Properties.Resources.DABANGG_3;
            txtTitle.Text = "DABANGG 3";
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            panelDetailOrder.Visible = false;
            panelOrder.Visible = true;
        }

        private void button52_Click(object sender, EventArgs e)
        {
            panelOrder.Visible = false;
            panelListFilm.Visible = true;
        }

        private void button51_Click(object sender, EventArgs e) //Button Confirm Order Seat & Date
        {
            if (newSeat < 2)
            {
                txtSeat.Text = Seat1;
            }
            else
            {
                txtSeat.Text = Seat1 + ", " + Seat2;
            }

            panelOrder.Visible = false;
            panelDetailOrder.Visible = true;
        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            con.Open();
            OleDbCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "INSERT INTO history (`date_order`, `title`, `seat`, `date_ticket`, `time`, `price`) values ('" + DateTime.Now + "','" + txtTitle.Text + "','" + txtSeat.Text + "','" + txtDateTicket.Text + "','" + txtTime.Text + "','" + txtPrice.Text + "')";
            cmd.ExecuteNonQuery();
            con.Close();

            formInvoice formInvoice = new formInvoice();
            formInvoice.invTitle.Text = txtTitle.Text;
            formInvoice.invDateNow.Text = DateTime.Now.ToString();
            formInvoice.invDateOrder.Text = txtDateTicket.Text;
            formInvoice.invPrice.Text = txtPrice.Text;
            formInvoice.invSeat.Text = txtSeat.Text;
            formInvoice.invTime.Text = txtTime.Text;

            formInvoice.Show();
            this.Hide();

        }

        private void cbTime_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (cbTime.Text == "12:00")
            {
                txtTime.Text = "12:00";
            } else
                if (cbTime.Text == "14:15")
            {
                txtTime.Text = "14:15";
            } else
                if (cbTime.Text == "16:30")
            {
                txtTime.Text = "16:30";
            } else
                if (cbTime.Text == "18:45")
            {
                txtTime.Text = "18:45";
            } else
                if (cbTime.Text == "21:00")
            {
                txtTime.Text = "21:00";
            }
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            string PilihHari = dateTimePicker1.Value.ToString("yyyy-MM-dd");
            txtDateTicket.Text = PilihHari;
        }

        private void panelOrder_Paint(object sender, PaintEventArgs e)
        {
            totalPrice = totalSeat * tiketPrice;
            txtPrice.Text = totalPrice.ToString();
            totalSeat = newSeat;
        }

        private void A1_Click(object sender, EventArgs e)
        {
            if (A1.BackColor == Color.LightGreen) {
                newSeat--;
                A1.BackColor = Color.LightSteelBlue;
            } else
            if (totalSeat > 1)
            {
                string msgWarning = "Jumlah Pemesanan Kursi telah Terpenuhi";
                MessageBox.Show(msgWarning);
                A1.BackColor = Color.LightSteelBlue;
            }
            else
            {
                newSeat++;

                if (newSeat < 2)
                {
                    Seat1 = "A1";
                }
                else
                {
                    Seat2 = "A1";
                }
                A1.BackColor = Color.LightGreen;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (button2.BackColor == Color.LightGreen)
            {
                newSeat--;
                button2.BackColor = Color.LightSteelBlue;
            }
            else
                if (totalSeat > 1)
                {
                    string msgWarning = "Jumlah Pemesanan Kursi telah Terpenuhi";
                    MessageBox.Show(msgWarning);
                    button2.BackColor = Color.LightSteelBlue;
                }
                else
                {
                    newSeat++;

                    if (newSeat < 2)
                    {
                        Seat1 = "A2";
                    }
                    else
                    {
                        Seat2 = "A2";
                    }

                    button2.BackColor = Color.LightGreen;
                }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (button4.BackColor == Color.LightGreen)
            {
                newSeat--;
                button4.BackColor = Color.LightSteelBlue;
            }
            else
                if (totalSeat > 1)
                {
                    string msgWarning = "Jumlah Pemesanan Kursi telah Terpenuhi";
                    MessageBox.Show(msgWarning);
                    button4.BackColor = Color.LightSteelBlue;
                }
                else
                {
                    newSeat++;


                    if (newSeat < 2)
                    {
                        Seat1 = "A3";
                    }
                    else
                    {
                        Seat2 = "A3";
                    }

                    button4.BackColor = Color.LightGreen;
                }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (button3.BackColor == Color.LightGreen)
            {
                newSeat--;
                button3.BackColor = Color.LightSteelBlue;
            }
            else
                if (totalSeat > 1)
                {
                    string msgWarning = "Jumlah Pemesanan Kursi telah Terpenuhi";
                    MessageBox.Show(msgWarning);
                    button3.BackColor = Color.LightSteelBlue;
                }
                else
                {
                    newSeat++;

                    if (newSeat < 2)
                    {
                        Seat1 = "A4";
                    }
                    else
                    {
                        Seat2 = "A4";
                    }
                    button3.BackColor = Color.LightGreen;
                }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (button8.BackColor == Color.LightGreen)
            {
                newSeat--;
                button8.BackColor = Color.LightSteelBlue;
            }
            else
                if (totalSeat > 1)
                {
                    string msgWarning = "Jumlah Pemesanan Kursi telah Terpenuhi";
                    MessageBox.Show(msgWarning);
                    button8.BackColor = Color.LightSteelBlue;
                }
                else
                {
                    newSeat++;

                    if (newSeat < 2)
                    {
                        Seat1 = "A5";
                    }
                    else
                    {
                        Seat2 = "A5";
                    }
                    button8.BackColor = Color.LightGreen;
                }
        }

        private void button40_Click(object sender, EventArgs e)
        {

            if (button40.BackColor == Color.LightGreen)
            {
                newSeat--;
                button40.BackColor = Color.LightSteelBlue;
            }
            else
                if (totalSeat > 1)
                {
                    string msgWarning = "Jumlah Pemesanan Kursi telah Terpenuhi";
                    MessageBox.Show(msgWarning);
                    button40.BackColor = Color.LightSteelBlue;
                }
                else
                {
                    newSeat++;

                    if (newSeat < 2)
                    {
                        Seat1 = "D1";
                    }
                    else
                    {
                        Seat2 = "D1";
                    }
                    button40.BackColor = Color.LightGreen;
                }
        }

        private void btn_find_Click(object sender, EventArgs e)
        {
            con.Open();
            OleDbCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "SELECT * FROM history WHERE invoice = " + txtFind.Text;
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            OleDbDataAdapter da = new OleDbDataAdapter(cmd);
            da.Fill(dt);
            dgHistory.DataSource = dt;
            con.Close();

            changeTime.Visible = true;
            btnUpdate.Visible = true;
            btnDelete.Visible = true;
            lbChangeTime.Visible = true;
        }

        public void loadData()
        {
            con.Open();
            OleDbCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "SELECT * FROM history ORDER BY invoice DESC";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            OleDbDataAdapter da = new OleDbDataAdapter(cmd);
            da.Fill(dt);
            dgHistory.DataSource = dt;
            con.Close();
        }

        private void button53_Click(object sender, EventArgs e)
        {
            con.Open();
            OleDbCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "DELETE FROM history WHERE invoice = " + txtFind.Text;
            cmd.ExecuteNonQuery();
            con.Close();
            loadData();
        }

        private void button54_Click(object sender, EventArgs e)
        {

            con.Open();
            OleDbCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "UPDATE `history` SET `time` = '" + changeTime.Text + "' WHERE invoice = " + txtFind.Text + "";
            cmd.ExecuteNonQuery();
            con.Close();

            con.Open();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "SELECT * FROM history WHERE invoice = " + txtFind.Text;
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            OleDbDataAdapter da = new OleDbDataAdapter(cmd);
            da.Fill(dt);
            dgHistory.DataSource = dt;
            con.Close();
        }

        private void button55_Click(object sender, EventArgs e)
        {
            panelListFilm.Visible = false;
            panelHistory.Visible = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            panelHistory.Visible = false;
            panelListFilm.Visible = true;
        }

        private void button5_Click(object sender, EventArgs e)
        {

            if (button5.BackColor == Color.LightGreen)
            {
                newSeat--;
                button5.BackColor = Color.LightSteelBlue;
            }
            else
                if (totalSeat > 1)
                {
                    string msgWarning = "Jumlah Pemesanan Kursi telah Terpenuhi";
                    MessageBox.Show(msgWarning);
                    button5.BackColor = Color.LightSteelBlue;
                }
                else
                {
                    newSeat++;

                    if (newSeat < 2)
                    {
                        Seat1 = "A6";
                    }
                    else
                    {
                        Seat2 = "A6";
                    }
                    button5.BackColor = Color.LightGreen;
                }
        }

        private void button12_Click(object sender, EventArgs e)
        {

            if (button12.BackColor == Color.LightGreen)
            {
                newSeat--;
                button12.BackColor = Color.LightSteelBlue;
            }
            else
                if (totalSeat > 1)
                {
                    string msgWarning = "Jumlah Pemesanan Kursi telah Terpenuhi";
                    MessageBox.Show(msgWarning);
                    button12.BackColor = Color.LightSteelBlue;
                }
                else
                {
                    newSeat++;

                    if (newSeat < 2)
                    {
                        Seat1 = "A7";
                    }
                    else
                    {
                        Seat2 = "A7";
                    }
                    button12.BackColor = Color.LightGreen;
                }
        }

        private void button11_Click(object sender, EventArgs e)
        {

            if (button11.BackColor == Color.LightGreen)
            {
                newSeat--;
                button11.BackColor = Color.LightSteelBlue;
            }
            else
                if (totalSeat > 1)
                {
                    string msgWarning = "Jumlah Pemesanan Kursi telah Terpenuhi";
                    MessageBox.Show(msgWarning);
                    button11.BackColor = Color.LightSteelBlue;
                }
                else
                {
                    newSeat++;

                    if (newSeat < 2)
                    {
                        Seat1 = "A8";
                    }
                    else
                    {
                        Seat2 = "A8";
                    }
                    button11.BackColor = Color.LightGreen;
                }
        }

        private void button10_Click(object sender, EventArgs e)
        {

            if (button10.BackColor == Color.LightGreen)
            {
                newSeat--;
                button10.BackColor = Color.LightSteelBlue;
            }
            else
                if (totalSeat > 1)
                {
                    string msgWarning = "Jumlah Pemesanan Kursi telah Terpenuhi";
                    MessageBox.Show(msgWarning);
                    button10.BackColor = Color.LightSteelBlue;
                }
                else
                {
                    newSeat++;

                    if (newSeat < 2)
                    {
                        Seat1 = "A9";
                    }
                    else
                    {
                        Seat2 = "A9";
                    }
                    button10.BackColor = Color.LightGreen;
                }
        }

        private void button9_Click(object sender, EventArgs e)
        {

            if (button9.BackColor == Color.LightGreen)
            {
                newSeat--;
                button9.BackColor = Color.LightSteelBlue;
            }
            else
                if (totalSeat > 1)
                {
                    string msgWarning = "Jumlah Pemesanan Kursi telah Terpenuhi";
                    MessageBox.Show(msgWarning);
                    button9.BackColor = Color.LightSteelBlue;
                }
                else
                {
                    newSeat++;

                    if (newSeat < 2)
                    {
                        Seat1 = "A10";
                    }
                    else
                    {
                        Seat2 = "A10";
                    }
                    button9.BackColor = Color.LightGreen;
                }
        }

        private void button20_Click(object sender, EventArgs e)
        {

            if (button20.BackColor == Color.LightGreen)
            {
                newSeat--;
                button20.BackColor = Color.LightSteelBlue;
            }
            else
                if (totalSeat > 1)
                {
                    string msgWarning = "Jumlah Pemesanan Kursi telah Terpenuhi";
                    MessageBox.Show(msgWarning);
                    button20.BackColor = Color.LightSteelBlue;
                }
                else
                {
                    newSeat++;

                    if (newSeat < 2)
                    {
                        Seat1 = "B1";
                    }
                    else
                    {
                        Seat2 = "B1";
                    }
                    button20.BackColor = Color.LightGreen;
                }
        }

        private void button19_Click(object sender, EventArgs e)
        {

            if (button19.BackColor == Color.LightGreen)
            {
                newSeat--;
                button19.BackColor = Color.LightSteelBlue;
            }
            else
                if (totalSeat > 1)
                {
                    string msgWarning = "Jumlah Pemesanan Kursi telah Terpenuhi";
                    MessageBox.Show(msgWarning);
                    button19.BackColor = Color.LightSteelBlue;
                }
                else
                {
                    newSeat++;

                    if (newSeat < 2)
                    {
                        Seat1 = "B2";
                    }
                    else
                    {
                        Seat2 = "B2";
                    }
                    button19.BackColor = Color.LightGreen;
                }
        }

        private void button18_Click(object sender, EventArgs e)
        {

            if (button18.BackColor == Color.LightGreen)
            {
                newSeat--;
                button18.BackColor = Color.LightSteelBlue;
            }
            else
                if (totalSeat > 1)
                {
                    string msgWarning = "Jumlah Pemesanan Kursi telah Terpenuhi";
                    MessageBox.Show(msgWarning);
                    button18.BackColor = Color.LightSteelBlue;
                }
                else
                {
                    newSeat++;

                    if (newSeat < 2)
                    {
                        Seat1 = "B3";
                    }
                    else
                    {
                        Seat2 = "B3";
                    }
                    button18.BackColor = Color.LightGreen;
                }
        }

        private void button17_Click(object sender, EventArgs e)
        {

            if (button17.BackColor == Color.LightGreen)
            {
                newSeat--;
                button17.BackColor = Color.LightSteelBlue;
            }
            else
                if (totalSeat > 1)
                {
                    string msgWarning = "Jumlah Pemesanan Kursi telah Terpenuhi";
                    MessageBox.Show(msgWarning);
                    button17.BackColor = Color.LightSteelBlue;
                }
                else
                {
                    newSeat++;

                    if (newSeat < 2)
                    {
                        Seat1 = "B4";
                    }
                    else
                    {
                        Seat2 = "B4";
                    }
                    button17.BackColor = Color.LightGreen;
                }
        }

        private void button16_Click(object sender, EventArgs e)
        {

            if (button16.BackColor == Color.LightGreen)
            {
                newSeat--;
                button16.BackColor = Color.LightSteelBlue;
            }
            else
                if (totalSeat > 1)
                {
                    string msgWarning = "Jumlah Pemesanan Kursi telah Terpenuhi";
                    MessageBox.Show(msgWarning);
                    button16.BackColor = Color.LightSteelBlue;
                }
                else
                {
                    newSeat++;

                    if (newSeat < 2)
                    {
                        Seat1 = "B5";
                    }
                    else
                    {
                        Seat2 = "B5";
                    }
                    button16.BackColor = Color.LightGreen;
                }
        }

        private void button15_Click(object sender, EventArgs e)
        {

            if (button15.BackColor == Color.LightGreen)
            {
                newSeat--;
                button15.BackColor = Color.LightSteelBlue;
            }
            else
                if (totalSeat > 1)
                {
                    string msgWarning = "Jumlah Pemesanan Kursi telah Terpenuhi";
                    MessageBox.Show(msgWarning);
                    button15.BackColor = Color.LightSteelBlue;
                }
                else
                {
                    newSeat++;

                    if (newSeat < 2)
                    {
                        Seat1 = "B6";
                    }
                    else
                    {
                        Seat2 = "B6";
                    }
                    button15.BackColor = Color.LightGreen;
                }
        }

        private void button14_Click(object sender, EventArgs e)
        {

            if (button14.BackColor == Color.LightGreen)
            {
                newSeat--;
                button14.BackColor = Color.LightSteelBlue;
            }
            else
                if (totalSeat > 1)
                {
                    string msgWarning = "Jumlah Pemesanan Kursi telah Terpenuhi";
                    MessageBox.Show(msgWarning);
                    button14.BackColor = Color.LightSteelBlue;
                }
                else
                {
                    newSeat++;

                    if (newSeat < 2)
                    {
                        Seat1 = "B7";
                    }
                    else
                    {
                        Seat2 = "B7";
                    }
                    button14.BackColor = Color.LightGreen;
                }
        }

        private void button13_Click(object sender, EventArgs e)
        {

            if (button13.BackColor == Color.LightGreen)
            {
                newSeat--;
                button13.BackColor = Color.LightSteelBlue;
            }
            else
                if (totalSeat > 1)
                {
                    string msgWarning = "Jumlah Pemesanan Kursi telah Terpenuhi";
                    MessageBox.Show(msgWarning);
                    button13.BackColor = Color.LightSteelBlue;
                }
                else
                {
                    newSeat++;

                    if (newSeat < 2)
                    {
                        Seat1 = "B8";
                    }
                    else
                    {
                        Seat2 = "B8";
                    }
                    button13.BackColor = Color.LightGreen;
                }
        }

        private void button7_Click(object sender, EventArgs e)
        {

            if (button7.BackColor == Color.LightGreen)
            {
                newSeat--;
                button7.BackColor = Color.LightSteelBlue;
            }
            else
                if (totalSeat > 1)
                {
                    string msgWarning = "Jumlah Pemesanan Kursi telah Terpenuhi";
                    MessageBox.Show(msgWarning);
                    button7.BackColor = Color.LightSteelBlue;
                }
                else
                {
                    newSeat++;

                    if (newSeat < 2)
                    {
                        Seat1 = "B9";
                    }
                    else
                    {
                        Seat2 = "B9";
                    }
                    button7.BackColor = Color.LightGreen;
                }
        }

        private void button6_Click(object sender, EventArgs e)
        {

            if (button6.BackColor == Color.LightGreen)
            {
                newSeat--;
                button6.BackColor = Color.LightSteelBlue;
            }
            else
                if (totalSeat > 1)
                {
                    string msgWarning = "Jumlah Pemesanan Kursi telah Terpenuhi";
                    MessageBox.Show(msgWarning);
                    button6.BackColor = Color.LightSteelBlue;
                }
                else
                {
                    newSeat++;

                    if (newSeat < 2)
                    {
                        Seat1 = "B10";
                    }
                    else
                    {
                        Seat2 = "B10";
                    }
                    button6.BackColor = Color.LightGreen;
                }
        }

        private void button30_Click(object sender, EventArgs e)
        {

            if (button30.BackColor == Color.LightGreen)
            {
                newSeat--;
                button30.BackColor = Color.LightSteelBlue;
            }
            else
                if (totalSeat > 1)
                {
                    string msgWarning = "Jumlah Pemesanan Kursi telah Terpenuhi";
                    MessageBox.Show(msgWarning);
                    button30.BackColor = Color.LightSteelBlue;
                }
                else
                {
                    newSeat++;

                    if (newSeat < 2)
                    {
                        Seat1 = "C1";
                    }
                    else
                    {
                        Seat2 = "C1";
                    }
                    button30.BackColor = Color.LightGreen;
                }
        }

        private void button29_Click(object sender, EventArgs e)
        {

            if (button29.BackColor == Color.LightGreen)
            {
                newSeat--;
                button29.BackColor = Color.LightSteelBlue;
            }
            else
                if (totalSeat > 1)
                {
                    string msgWarning = "Jumlah Pemesanan Kursi telah Terpenuhi";
                    MessageBox.Show(msgWarning);
                    button29.BackColor = Color.LightSteelBlue;
                }
                else
                {
                    newSeat++;

                    if (newSeat < 2)
                    {
                        Seat1 = "C2";
                    }
                    else
                    {
                        Seat2 = "C2";
                    }
                    button29.BackColor = Color.LightGreen;
                }
        }

        private void button28_Click(object sender, EventArgs e)
        {

            if (button28.BackColor == Color.LightGreen)
            {
                newSeat--;
                button28.BackColor = Color.LightSteelBlue;
            }
            else
                if (totalSeat > 1)
                {
                    string msgWarning = "Jumlah Pemesanan Kursi telah Terpenuhi";
                    MessageBox.Show(msgWarning);
                    button28.BackColor = Color.LightSteelBlue;
                }
                else
                {
                    newSeat++;

                    if (newSeat < 2)
                    {
                        Seat1 = "C3";
                    }
                    else
                    {
                        Seat2 = "C3";
                    }
                    button28.BackColor = Color.LightGreen;
                }
        }

        private void button27_Click(object sender, EventArgs e)
        {

            if (button27.BackColor == Color.LightGreen)
            {
                newSeat--;
                button27.BackColor = Color.LightSteelBlue;
            }
            else
                if (totalSeat > 1)
                {
                    string msgWarning = "Jumlah Pemesanan Kursi telah Terpenuhi";
                    MessageBox.Show(msgWarning);
                    button27.BackColor = Color.LightSteelBlue;
                }
                else
                {
                    newSeat++;

                    if (newSeat < 2)
                    {
                        Seat1 = "C4";
                    }
                    else
                    {
                        Seat2 = "C4";
                    }
                    button27.BackColor = Color.LightGreen;
                }
        }

        private void button26_Click(object sender, EventArgs e)
        {

            if (button26.BackColor == Color.LightGreen)
            {
                newSeat--;
                button26.BackColor = Color.LightSteelBlue;
            }
            else
                if (totalSeat > 1)
                {
                    string msgWarning = "Jumlah Pemesanan Kursi telah Terpenuhi";
                    MessageBox.Show(msgWarning);
                    button26.BackColor = Color.LightSteelBlue;
                }
                else
                {
                    newSeat++;

                    if (newSeat < 2)
                    {
                        Seat1 = "C5";
                    }
                    else
                    {
                        Seat2 = "C5";
                    }
                    button26.BackColor = Color.LightGreen;
                }
        }

        private void button25_Click(object sender, EventArgs e)
        {

            if (button25.BackColor == Color.LightGreen)
            {
                newSeat--;
                button25.BackColor = Color.LightSteelBlue;
            }
            else
                if (totalSeat > 1)
                {
                    string msgWarning = "Jumlah Pemesanan Kursi telah Terpenuhi";
                    MessageBox.Show(msgWarning);
                    button25.BackColor = Color.LightSteelBlue;
                }
                else
                {
                    newSeat++;

                    if (newSeat < 2)
                    {
                        Seat1 = "C6";
                    }
                    else
                    {
                        Seat2 = "C6";
                    }
                    button25.BackColor = Color.LightGreen;
                }
        }

        private void button24_Click(object sender, EventArgs e)
        {

            if (button24.BackColor == Color.LightGreen)
            {
                newSeat--;
                button24.BackColor = Color.LightSteelBlue;
            }
            else
                if (totalSeat > 1)
                {
                    string msgWarning = "Jumlah Pemesanan Kursi telah Terpenuhi";
                    MessageBox.Show(msgWarning);
                    button24.BackColor = Color.LightSteelBlue;
                }
                else
                {
                    newSeat++;

                    if (newSeat < 2)
                    {
                        Seat1 = "C7";
                    }
                    else
                    {
                        Seat2 = "C7";
                    }
                    button24.BackColor = Color.LightGreen;
                }
        }

        private void button23_Click(object sender, EventArgs e)
        {

            if (button23.BackColor == Color.LightGreen)
            {
                newSeat--;
                button23.BackColor = Color.LightSteelBlue;
            }
            else
                if (totalSeat > 1)
                {
                    string msgWarning = "Jumlah Pemesanan Kursi telah Terpenuhi";
                    MessageBox.Show(msgWarning);
                    button23.BackColor = Color.LightSteelBlue;
                }
                else
                {
                    newSeat++;

                    if (newSeat < 2)
                    {
                        Seat1 = "C8";
                    }
                    else
                    {
                        Seat2 = "C8";
                    }
                    button23.BackColor = Color.LightGreen;
                }
        }

        private void button22_Click(object sender, EventArgs e)
        {

            if (button22.BackColor == Color.LightGreen)
            {
                newSeat--;
                button22.BackColor = Color.LightSteelBlue;
            }
            else
                if (totalSeat > 1)
                {
                    string msgWarning = "Jumlah Pemesanan Kursi telah Terpenuhi";
                    MessageBox.Show(msgWarning);
                    button22.BackColor = Color.LightSteelBlue;
                }
                else
                {
                    newSeat++;

                    if (newSeat < 2)
                    {
                        Seat1 = "C9";
                    }
                    else
                    {
                        Seat2 = "C9";
                    }
                    button22.BackColor = Color.LightGreen;
                }
        }

        private void button21_Click(object sender, EventArgs e)
        {

            if (button21.BackColor == Color.LightGreen)
            {
                newSeat--;
                button21.BackColor = Color.LightSteelBlue;
            }
            else
                if (totalSeat > 1)
                {
                    string msgWarning = "Jumlah Pemesanan Kursi telah Terpenuhi";
                    MessageBox.Show(msgWarning);
                    button21.BackColor = Color.LightSteelBlue;
                }
                else
                {
                    newSeat++;

                    if (newSeat < 2)
                    {
                        Seat1 = "C10";
                    }
                    else
                    {
                        Seat2 = "C10";
                    }
                    button21.BackColor = Color.LightGreen;
                }
        }

        private void button39_Click(object sender, EventArgs e)
        {

            if (button39.BackColor == Color.LightGreen)
            {
                newSeat--;
                button39.BackColor = Color.LightSteelBlue;
            }
            else
                if (totalSeat > 1)
                {
                    string msgWarning = "Jumlah Pemesanan Kursi telah Terpenuhi";
                    MessageBox.Show(msgWarning);
                    button39.BackColor = Color.LightSteelBlue;
                }
                else
                {
                    newSeat++;

                    if (newSeat < 2)
                    {
                        Seat1 = "D2";
                    }
                    else
                    {
                        Seat2 = "D2";
                    }
                    button39.BackColor = Color.LightGreen;
                }
        }

        private void button38_Click(object sender, EventArgs e)
        {

            if (button38.BackColor == Color.LightGreen)
            {
                newSeat--;
                button38.BackColor = Color.LightSteelBlue;
            }
            else
                if (totalSeat > 1)
                {
                    string msgWarning = "Jumlah Pemesanan Kursi telah Terpenuhi";
                    MessageBox.Show(msgWarning);
                    button38.BackColor = Color.LightSteelBlue;
                }
                else
                {
                    newSeat++;

                    if (newSeat < 2)
                    {
                        Seat1 = "D3";
                    }
                    else
                    {
                        Seat2 = "D3";
                    }
                    button38.BackColor = Color.LightGreen;
                }
        }

        private void button37_Click(object sender, EventArgs e)
        {

            if (button37.BackColor == Color.LightGreen)
            {
                newSeat--;
                button37.BackColor = Color.LightSteelBlue;
            }
            else
                if (totalSeat > 1)
                {
                    string msgWarning = "Jumlah Pemesanan Kursi telah Terpenuhi";
                    MessageBox.Show(msgWarning);
                    button37.BackColor = Color.LightSteelBlue;
                }
                else
                {
                    newSeat++;

                    if (newSeat < 2)
                    {
                        Seat1 = "D4";
                    }
                    else
                    {
                        Seat2 = "D4";
                    }
                    button37.BackColor = Color.LightGreen;
                }
        }

        private void button36_Click(object sender, EventArgs e)
        {

            if (button36.BackColor == Color.LightGreen)
            {
                newSeat--;
                button36.BackColor = Color.LightSteelBlue;
            }
            else
                if (totalSeat > 1)
                {
                    string msgWarning = "Jumlah Pemesanan Kursi telah Terpenuhi";
                    MessageBox.Show(msgWarning);
                    button36.BackColor = Color.LightSteelBlue;
                }
                else
                {
                    newSeat++;

                    if (newSeat < 2)
                    {
                        Seat1 = "D5";
                    }
                    else
                    {
                        Seat2 = "D5";
                    }
                    button36.BackColor = Color.LightGreen;
                }
        }

        private void button35_Click(object sender, EventArgs e)
        {

            if (button35.BackColor == Color.LightGreen)
            {
                newSeat--;
                button35.BackColor = Color.LightSteelBlue;
            }
            else
                if (totalSeat > 1)
                {
                    string msgWarning = "Jumlah Pemesanan Kursi telah Terpenuhi";
                    MessageBox.Show(msgWarning);
                    button35.BackColor = Color.LightSteelBlue;
                }
                else
                {
                    newSeat++;

                    if (newSeat < 2)
                    {
                        Seat1 = "D6";
                    }
                    else
                    {
                        Seat2 = "D6";
                    }
                    button35.BackColor = Color.LightGreen;
                }
        }

        private void button34_Click(object sender, EventArgs e)
        {

            if (button34.BackColor == Color.LightGreen)
            {
                newSeat--;
                button34.BackColor = Color.LightSteelBlue;
            }
            else
                if (totalSeat > 1)
                {
                    string msgWarning = "Jumlah Pemesanan Kursi telah Terpenuhi";
                    MessageBox.Show(msgWarning);
                    button34.BackColor = Color.LightSteelBlue;
                }
                else
                {
                    newSeat++;

                    if (newSeat < 2)
                    {
                        Seat1 = "D7";
                    }
                    else
                    {
                        Seat2 = "D7";
                    }
                    button34.BackColor = Color.LightGreen;
                }
        }

        private void button33_Click(object sender, EventArgs e)
        {

            if (button33.BackColor == Color.LightGreen)
            {
                newSeat--;
                button33.BackColor = Color.LightSteelBlue;
            }
            else
                if (totalSeat > 1)
                {
                    string msgWarning = "Jumlah Pemesanan Kursi telah Terpenuhi";
                    MessageBox.Show(msgWarning);
                    button33.BackColor = Color.LightSteelBlue;
                }
                else
                {
                    newSeat++;

                    if (newSeat < 2)
                    {
                        Seat1 = "D8";
                    }
                    else
                    {
                        Seat2 = "D8";
                    }
                    button33.BackColor = Color.LightGreen;
                }
        }

        private void button32_Click(object sender, EventArgs e)
        {

            if (button32.BackColor == Color.LightGreen)
            {
                newSeat--;
                button32.BackColor = Color.LightSteelBlue;
            }
            else
                if (totalSeat > 1)
                {
                    string msgWarning = "Jumlah Pemesanan Kursi telah Terpenuhi";
                    MessageBox.Show(msgWarning);
                    button32.BackColor = Color.LightSteelBlue;
                }
                else
                {
                    newSeat++;

                    if (newSeat < 2)
                    {
                        Seat1 = "D9";
                    }
                    else
                    {
                        Seat2 = "D9";
                    }
                    button32.BackColor = Color.LightGreen;
                }
        }

        private void button31_Click(object sender, EventArgs e)
        {

            if (button31.BackColor == Color.LightGreen)
            {
                newSeat--;
                button31.BackColor = Color.LightSteelBlue;
            }
            else
                if (totalSeat > 1)
                {
                    string msgWarning = "Jumlah Pemesanan Kursi telah Terpenuhi";
                    MessageBox.Show(msgWarning);
                    button31.BackColor = Color.LightSteelBlue;
                }
                else
                {
                    newSeat++;

                    if (newSeat < 2)
                    {
                        Seat1 = "D10";
                    }
                    else
                    {
                        Seat2 = "D10";
                    }
                    button31.BackColor = Color.LightGreen;
                }
        }

        private void button50_Click(object sender, EventArgs e)
        {

            if (button50.BackColor == Color.LightGreen)
            {
                newSeat--;
                button50.BackColor = Color.LightSteelBlue;
            }
            else
                if (totalSeat > 1)
                {
                    string msgWarning = "Jumlah Pemesanan Kursi telah Terpenuhi";
                    MessageBox.Show(msgWarning);
                    button50.BackColor = Color.LightSteelBlue;
                }
                else
                {
                    newSeat++;

                    if (newSeat < 2)
                    {
                        Seat1 = "E1";
                    }
                    else
                    {
                        Seat2 = "E1";
                    }
                    button50.BackColor = Color.LightGreen;
                }
        }

        private void button49_Click(object sender, EventArgs e)
        {

            if (button49.BackColor == Color.LightGreen)
            {
                newSeat--;
                button49.BackColor = Color.LightSteelBlue;
            }
            else
                if (totalSeat > 1)
                {
                    string msgWarning = "Jumlah Pemesanan Kursi telah Terpenuhi";
                    MessageBox.Show(msgWarning);
                    button49.BackColor = Color.LightSteelBlue;
                }
                else
                {
                    newSeat++;

                    if (newSeat < 2)
                    {
                        Seat1 = "E2";
                    }
                    else
                    {
                        Seat2 = "E2";
                    }
                    button49.BackColor = Color.LightGreen;
                }
        }

        private void button48_Click(object sender, EventArgs e)
        {

            if (button48.BackColor == Color.LightGreen)
            {
                newSeat--;
                button48.BackColor = Color.LightSteelBlue;
            }
            else
                if (totalSeat > 1)
                {
                    string msgWarning = "Jumlah Pemesanan Kursi telah Terpenuhi";
                    MessageBox.Show(msgWarning);
                    button48.BackColor = Color.LightSteelBlue;
                }
                else
                {
                    newSeat++;

                    if (newSeat < 2)
                    {
                        Seat1 = "E3";
                    }
                    else
                    {
                        Seat2 = "E3";
                    }
                    button48.BackColor = Color.LightGreen;
                }
        }

        private void button47_Click(object sender, EventArgs e)
        {

            if (button47.BackColor == Color.LightGreen)
            {
                newSeat--;
                button47.BackColor = Color.LightSteelBlue;
            }
            else
                if (totalSeat > 1)
                {
                    string msgWarning = "Jumlah Pemesanan Kursi telah Terpenuhi";
                    MessageBox.Show(msgWarning);
                    button47.BackColor = Color.LightSteelBlue;
                }
                else
                {
                    newSeat++;

                    if (newSeat < 2)
                    {
                        Seat1 = "E4";
                    }
                    else
                    {
                        Seat2 = "E4";
                    }
                    button47.BackColor = Color.LightGreen;
                }
        }

        private void button46_Click(object sender, EventArgs e)
        {

            if (button46.BackColor == Color.LightGreen)
            {
                newSeat--;
                button46.BackColor = Color.LightSteelBlue;
            }
            else
                if (totalSeat > 1)
                {
                    string msgWarning = "Jumlah Pemesanan Kursi telah Terpenuhi";
                    MessageBox.Show(msgWarning);
                    button46.BackColor = Color.LightSteelBlue;
                }
                else
                {
                    newSeat++;

                    if (newSeat < 2)
                    {
                        Seat1 = "E5";
                    }
                    else
                    {
                        Seat2 = "E5";
                    }
                    button46.BackColor = Color.LightGreen;
                }
        }

        private void button45_Click(object sender, EventArgs e)
        {

            if (button45.BackColor == Color.LightGreen)
            {
                newSeat--;
                button45.BackColor = Color.LightSteelBlue;
            }
            else
                if (totalSeat > 1)
                {
                    string msgWarning = "Jumlah Pemesanan Kursi telah Terpenuhi";
                    MessageBox.Show(msgWarning);
                    button45.BackColor = Color.LightSteelBlue;
                }
                else
                {
                    newSeat++;

                    if (newSeat < 2)
                    {
                        Seat1 = "E6";
                    }
                    else
                    {
                        Seat2 = "E6";
                    }
                    button45.BackColor = Color.LightGreen;
                }
        }

        private void button44_Click(object sender, EventArgs e)
        {

            if (button44.BackColor == Color.LightGreen)
            {
                newSeat--;
                button44.BackColor = Color.LightSteelBlue;
            }
            else
                if (totalSeat > 1)
                {
                    string msgWarning = "Jumlah Pemesanan Kursi telah Terpenuhi";
                    MessageBox.Show(msgWarning);
                    button44.BackColor = Color.LightSteelBlue;
                }
                else
                {
                    newSeat++;

                    if (newSeat < 2)
                    {
                        Seat1 = "E7";
                    }
                    else
                    {
                        Seat2 = "E7";
                    }
                    button44.BackColor = Color.LightGreen;
                }
        }

        private void button43_Click(object sender, EventArgs e)
        {

            if (button43.BackColor == Color.LightGreen)
            {
                newSeat--;
                button43.BackColor = Color.LightSteelBlue;
            }
            else
                if (totalSeat > 1)
                {
                    string msgWarning = "Jumlah Pemesanan Kursi telah Terpenuhi";
                    MessageBox.Show(msgWarning);
                    button43.BackColor = Color.LightSteelBlue;
                }
                else
                {
                    newSeat++;

                    if (newSeat < 2)
                    {
                        Seat1 = "E8";
                    }
                    else
                    {
                        Seat2 = "E8";
                    }
                    button43.BackColor = Color.LightGreen;
                }
        }

        private void button42_Click(object sender, EventArgs e)
        {

            if (button42.BackColor == Color.LightGreen)
            {
                newSeat--;
                button42.BackColor = Color.LightSteelBlue;
            }
            else
                if (totalSeat > 1)
                {
                    string msgWarning = "Jumlah Pemesanan Kursi telah Terpenuhi";
                    MessageBox.Show(msgWarning);
                    button42.BackColor = Color.LightSteelBlue;
                }
                else
                {
                    newSeat++;

                    if (newSeat < 2)
                    {
                        Seat1 = "E9";
                    }
                    else
                    {
                        Seat2 = "E9";
                    }
                    button42.BackColor = Color.LightGreen;
                }
        }

        private void button41_Click(object sender, EventArgs e)
        {

            if (button41.BackColor == Color.LightGreen)
            {
                newSeat--;
                button41.BackColor = Color.LightSteelBlue;
            }
            else
                if (totalSeat > 1)
                {
                    string msgWarning = "Jumlah Pemesanan Kursi telah Terpenuhi";
                    MessageBox.Show(msgWarning);
                    button41.BackColor = Color.LightSteelBlue;
                }
                else
                {
                    newSeat++;

                    if (newSeat < 2)
                    {
                        Seat1 = "E10";
                    }
                    else
                    {
                        Seat2 = "E10";
                    }
                    button41.BackColor = Color.LightGreen;
                }
        }

        private void btnPrintHistory_Click(object sender, EventArgs e)
        {
            formLaporanBioskop formLaporan = new formLaporanBioskop();
            NewCrystalReportLaporan cryReport = new NewCrystalReportLaporan();

            formLaporan.crystalReportViewer1.SelectionFormula = "Year({history.date_ticket}) = " + dateTimePickerDaily.Value.ToString("yyyy") + " AND Month({history.date_ticket}) = " + dateTimePickerDaily.Value.ToString("MM") + " AND Day({history.date_ticket}) = " + dateTimePickerDaily.Value.ToString("dd");
            formLaporan.crystalReportViewer1.ReportSource = cryReport;
            formLaporan.crystalReportViewer1.RefreshReport();

            formLaporan.Show();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {

            formLaporanBioskop formLaporan = new formLaporanBioskop();
            NewCrystalReportLaporan cryReport = new NewCrystalReportLaporan();

            formLaporan.crystalReportViewer1.SelectionFormula = "(DAY({history.date_ticket}) = " + dateTimePickerStart.Value.ToString("dd"));
            formLaporan.crystalReportViewer1.ReportSource = cryReport;
            formLaporan.crystalReportViewer1.RefreshReport();

            formLaporan.Show();
        }
    }
}
