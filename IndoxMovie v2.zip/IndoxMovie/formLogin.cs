﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace IndoxMovie
{
    public partial class formLogin : Form
    {
        OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\DEATA\Documents\IndoxMovie\IndoxMovie\indoxMovie.mdb");

        public formLogin()
        {
            InitializeComponent();
        }

        private void loginBtn_Click(object sender, EventArgs e)
        {
            LoginUser();
        }


        private void LoginUser() {
                try
                {
                    string sql;
                    OleDbCommand cmd;
                    OleDbDataAdapter da;
                    DataSet ds = new DataSet("ds");

                    con.Open();

                    sql="SELECT * FROM admin WHERE username = '" + username.Text + "'";
                    cmd = new OleDbCommand(sql, con);
                    da = new OleDbDataAdapter(cmd);

                    da.Fill(ds);

                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        if (password.Text.ToLower().Trim() == ds.Tables[0].Rows[0]["password"].ToString().Trim().ToLower())
                        {
                            this.Hide();
                            password.Text = "";
                            formDashboard formDashboard = new formDashboard();
                            formDashboard.Show();
                            con.Close();
                        }
                        else
                        {
                            MessageBox.Show("Password salah");
                            password.Focus();
                            con.Close();
                        }
                    }
                    else {
                        MessageBox.Show("Username tidak terdaftar");
                        username.Focus();
                        con.Close();
                    }

                }
                catch (Exception ex)
                {
                    con.Close();
                    MessageBox.Show(ex.Message);
                }
        }
    }
}
