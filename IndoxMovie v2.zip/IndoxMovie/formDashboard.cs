﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace IndoxMovie
{
    public partial class formDashboard : Form
    {
        int newSeat = 0;
        int tiketPrice = 35000;
        int totalPrice, totalSeat;

        OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\DEATA\Documents\IndoxMovie\IndoxMovie\indoxMovie.mdb");

        public formDashboard()
        {
            InitializeComponent();
            con.Open();
            OleDbCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "SELECT * FROM history ORDER BY invoice DESC";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            OleDbDataAdapter da = new OleDbDataAdapter(cmd);
            da.Fill(dt);
            dgHistory.DataSource = dt;
            con.Close();
        }


        private void imgJumanji_Click_1(object sender, EventArgs e)
        {
            panelListFilm.Visible = false;
            panelOrder.Visible = true;
            imgMovie.BackgroundImage = IndoxMovie.Properties.Resources.JUMANJI___THE_NEXT_LEVEL;
            imgDetailOrder.BackgroundImage = IndoxMovie.Properties.Resources.JUMANJI___THE_NEXT_LEVEL;
            txtTitle.Text = "JUMANJI: THE NEXT LEVEL";
        }

        private void imgJeritanMalam_Click(object sender, EventArgs e)
        {
            panelListFilm.Visible = false;
            panelOrder.Visible = true;
            imgMovie.BackgroundImage = IndoxMovie.Properties.Resources.JERITAN_MALAM;
            imgDetailOrder.BackgroundImage = IndoxMovie.Properties.Resources.JERITAN_MALAM;
            txtTitle.Text = "JERITAN MALAM";
        }

        private void imgFrozen2_Click(object sender, EventArgs e)
        {
            panelListFilm.Visible = false;
            panelOrder.Visible = true;
            imgMovie.BackgroundImage = IndoxMovie.Properties.Resources.FROZEN_2;
            imgDetailOrder.BackgroundImage = IndoxMovie.Properties.Resources.FROZEN_2;
            txtTitle.Text = "FROZEN 2";
        }

        private void imgBlackChristmas_Click(object sender, EventArgs e)
        {
            panelListFilm.Visible = false;
            panelOrder.Visible = true;
            imgMovie.BackgroundImage = IndoxMovie.Properties.Resources.BLACK_CHRISTMAS;
            imgDetailOrder.BackgroundImage = IndoxMovie.Properties.Resources.BLACK_CHRISTMAS;
            txtTitle.Text = "BLACK CHRISTMAS";
        }

        private void imgJoker_Click_1(object sender, EventArgs e)
        {
            panelListFilm.Visible = false;
            panelOrder.Visible = true;
            imgMovie.BackgroundImage = IndoxMovie.Properties.Resources.JOKER;
            imgDetailOrder.BackgroundImage = IndoxMovie.Properties.Resources.JOKER;
            txtTitle.Text = "JOKER";
        }

        private void imgRasuk2_Click(object sender, EventArgs e)
        {
            panelListFilm.Visible = false;
            panelOrder.Visible = true;
            imgMovie.BackgroundImage = IndoxMovie.Properties.Resources.RASUK_2;
            imgDetailOrder.BackgroundImage = IndoxMovie.Properties.Resources.RASUK_2;
            txtTitle.Text = "RASUK 2";
        }

        private void imgUnderwater_Click(object sender, EventArgs e)
        {
            panelListFilm.Visible = false;
            panelOrder.Visible = true;
            imgMovie.BackgroundImage = IndoxMovie.Properties.Resources.UNDERWATER;
            imgDetailOrder.BackgroundImage = IndoxMovie.Properties.Resources.UNDERWATER;
            txtTitle.Text = "UNDERWATER";
        }

        private void imgDabangg3_Click(object sender, EventArgs e)
        {
            panelListFilm.Visible = false;
            panelOrder.Visible = true;
            imgMovie.BackgroundImage = IndoxMovie.Properties.Resources.DABANGG_3;
            imgDetailOrder.BackgroundImage = IndoxMovie.Properties.Resources.DABANGG_3;
            txtTitle.Text = "DABANGG 3";
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            panelDetailOrder.Visible = false;
            panelOrder.Visible = true;
        }

        private void button52_Click(object sender, EventArgs e)
        {
            panelOrder.Visible = false;
            panelListFilm.Visible = true;
        }

        private void button51_Click(object sender, EventArgs e)
        {
            panelOrder.Visible = false;
            panelDetailOrder.Visible = true;
        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            con.Open();
            OleDbCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "INSERT INTO history (`date_order`, `title`, `seat`, `date_ticket`, `time`, `price`) values ('" + DateTime.Now + "','" + txtTitle.Text + "','" + txtSeat.Text + "','" + txtDateTicket.Text + "','" + txtTime.Text + "','" + txtPrice.Text + "')";
            cmd.ExecuteNonQuery();
            con.Close();

            formInvoice formInvoice = new formInvoice();
            formInvoice.invTitle.Text = txtTitle.Text;
            formInvoice.invDateNow.Text = DateTime.Now.ToString();
            formInvoice.invDateOrder.Text = txtDateTicket.Text;
            formInvoice.invPrice.Text = txtPrice.Text;
            formInvoice.invSeat.Text = txtSeat.Text;
            formInvoice.invTime.Text = txtTime.Text;

            formInvoice.Show();
            this.Hide();

        }

        private void cbTime_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (cbTime.Text == "12:00")
            {
                txtTime.Text = "12:00";
            } else
                if (cbTime.Text == "14:15")
            {
                txtTime.Text = "14:15";
            } else
                if (cbTime.Text == "16:30")
            {
                txtTime.Text = "16:30";
            } else
                if (cbTime.Text == "18:45")
            {
                txtTime.Text = "18:45";
            } else
                if (cbTime.Text == "21:00")
            {
                txtTime.Text = "21:00";
            }
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            string PilihHari = dateTimePicker1.Value.ToString("yyyy-MM-dd");
            txtDateTicket.Text = PilihHari;
        }

        private void panelOrder_Paint(object sender, PaintEventArgs e)
        {
            totalPrice = totalSeat * tiketPrice;
            txtPrice.Text = totalPrice.ToString();
            totalSeat = newSeat;
        }

        private void A1_Click(object sender, EventArgs e)
        {
            if (A1.BackColor == Color.LightGreen) {
                newSeat--;
                A1.BackColor = Color.LightSteelBlue;
            } else
            if (totalSeat > 1)
            {
                string msgWarning = "Jumlah Pemesanan Kursi telah Terpenuhi";
                MessageBox.Show(msgWarning);
                A1.BackColor = Color.LightSteelBlue;
            }
            else
            {
                newSeat++;
                A1.BackColor = Color.LightGreen;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (button2.BackColor == Color.LightGreen)
            {
                newSeat--;
                button2.BackColor = Color.LightSteelBlue;
            }
            else
                if (totalSeat > 1)
                {
                    string msgWarning = "Jumlah Pemesanan Kursi telah Terpenuhi";
                    MessageBox.Show(msgWarning);
                    button2.BackColor = Color.LightSteelBlue;
                }
                else
                {
                    newSeat++;
                    button2.BackColor = Color.LightGreen;
                }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (button4.BackColor == Color.LightGreen)
            {
                newSeat--;
                button4.BackColor = Color.LightSteelBlue;
            }
            else
                if (totalSeat > 1)
                {
                    string msgWarning = "Jumlah Pemesanan Kursi telah Terpenuhi";
                    MessageBox.Show(msgWarning);
                    button4.BackColor = Color.LightSteelBlue;
                }
                else
                {
                    newSeat++;
                    button4.BackColor = Color.LightGreen;
                }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (button3.BackColor == Color.LightGreen)
            {
                newSeat--;
                button3.BackColor = Color.LightSteelBlue;
            }
            else
                if (totalSeat > 1)
                {
                    string msgWarning = "Jumlah Pemesanan Kursi telah Terpenuhi";
                    MessageBox.Show(msgWarning);
                    button3.BackColor = Color.LightSteelBlue;
                }
                else
                {
                    newSeat++;
                    button3.BackColor = Color.LightGreen;
                }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (button8.BackColor == Color.LightGreen)
            {
                newSeat--;
                button8.BackColor = Color.LightSteelBlue;
            }
            else
                if (totalSeat > 1)
                {
                    string msgWarning = "Jumlah Pemesanan Kursi telah Terpenuhi";
                    MessageBox.Show(msgWarning);
                    button8.BackColor = Color.LightSteelBlue;
                }
                else
                {
                    newSeat++;
                    button8.BackColor = Color.LightGreen;
                }
        }

        private void button40_Click(object sender, EventArgs e)
        {

        }

        private void btn_find_Click(object sender, EventArgs e)
        {
            con.Open();
            OleDbCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "SELECT * FROM history WHERE invoice = " + txtFind.Text;
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            OleDbDataAdapter da = new OleDbDataAdapter(cmd);
            da.Fill(dt);
            dgHistory.DataSource = dt;
            con.Close();
        }

        public void loadData()
        {
            con.Open();
            OleDbCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "SELECT * FROM history ORDER BY invoice DESC";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            OleDbDataAdapter da = new OleDbDataAdapter(cmd);
            da.Fill(dt);
            dgHistory.DataSource = dt;
            con.Close();
        }

        private void button53_Click(object sender, EventArgs e)
        {
            con.Open();
            OleDbCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "DELETE FROM history WHERE invoice = " + txtFind.Text;
            cmd.ExecuteNonQuery();
            con.Close();
            loadData();
        }

        private void button54_Click(object sender, EventArgs e)
        {

            con.Open();
            OleDbCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "UPDATE `history` SET `time` = '" + changeTime.Text + "' WHERE invoice = " + txtFind.Text + "";
            cmd.ExecuteNonQuery();
            con.Close();

            con.Open();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "SELECT * FROM history WHERE invoice = " + txtFind.Text;
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            OleDbDataAdapter da = new OleDbDataAdapter(cmd);
            da.Fill(dt);
            dgHistory.DataSource = dt;
            con.Close();
        }

        private void button55_Click(object sender, EventArgs e)
        {
            panelListFilm.Visible = false;
            panelHistory.Visible = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            panelHistory.Visible = false;
            panelListFilm.Visible = true;
        }

    }
}
